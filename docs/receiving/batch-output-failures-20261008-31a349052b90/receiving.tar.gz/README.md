# UMA native batch output failure correction

Prepared by `estate-31a349052b90 / product_execution`, 2026-10-08 UTC.

## Product result

The native `uma-sim batch` command printed file-open and JSONL-write errors but
returned process status 0. A shell script could therefore analyze an incomplete
batch or report a failed export as successful.

The candidate changes exactly two existing `return` statements to
`std::process::exit(1)` in `cmd_batch`. It preserves the exact error messages,
success path, output schema, existing file handling, simulation policy, and
`analyze`. Output is still written directly; no atomicity or durability change
is introduced.

## Frozen source boundary

Receiving main is `0bc58cb83e89f07c6af3056dd7c37436906d994f`, verified again after
native qualification. The full main tree was read and was not truncated. There
is no `AGENTS.md` in that tree. Candidate source paths are only:

| Receiving repository path | Packet source |
|---|---|
| `uma-sim-core/src/bin/uma-sim.rs` | `candidate/uma-sim.rs` |
| `uma-sim-core/tests/batch_output_failures.rs` | `batch_output_failures.rs` |
| `docs/batch-output-failures.md` | `batch-output-failures.md` |

`publication-inputs.json` pins every source byte, the baseline blob, and the
intended new paths. `evidence/source.patch` contains the complete production
diff. No package dependency, Cargo manifest, workflow, game rule, Rust API,
career laboratory, browser UI, MCP, or Node terminal file is changed.

The current issue66/open-issue/open-PR reads and the independent ownership
assist are retained in `coordination.json`. Existing browser/session, lab trace,
retained-log, checkpoint replacement/report, MCP composition and Node terminal
owners retain their scopes. The parent accepted this precise isolated boundary
before implementation. No GitHub mutation was attempted while the separate
secondary content-creation limit remained known.

## Consequential native results

The final test file is unchanged between the final baseline and candidate runs.
It launches the real native CLI and uses the real simulator/data readers and
operating-system writes. No writer, simulator result, or process exit is mocked.

| Actual case | Original CLI | Corrected CLI | Preserved file state |
|---|---:|---:|---|
| Output names an existing directory | Exit 0: erroneous success | Exit 1 | Directory and its 30-byte sentinel unchanged; no output file |
| Child reaches an actual file-size limit while writing the second career | Exit 0: erroneous success | Exit 1 | Same 311-byte prefix: one complete 294-byte JSONL record plus 17 bytes of the next |
| Three requested seeds write successfully | Exit 0 | Exit 0 | Same 884 bytes, three valid careers, seeds 42/43/44 in order |

Both error paths retain their existing stderr (`Failed to open ...` and
`write error: File too large (os error 27)`) and print no successful batch summary.
The complete and partial files were compared byte for byte across the two
versions. The successful records and the first partial-file record are parsed
as real JSON in the tests.

**Final baseline: 1 pass / 2 intended failures. Final candidate: 3 passes /
0 failures, no skips.** There are three distinct methods and four actual CLI
invocations per final run: the midstream method first makes its own complete
reference batch. The first authored baseline run is also retained separately;
it found the same two failures. That preliminary test source was then formatted
and tightened to require exit 1, with its signal constants gated specifically to
Linux x86-64. The final-source baseline result is not substituted with that
earlier result, and repeated executions are not additional distinct tests.

`rustfmt --edition=2021 --check` passes on the final CLI and regression source.

## Native build provenance and limits

Rust is the existing read-only 1.99.0 toolchain (`b940084d7`, Linux x86-64).
`receive.py` compiled the exact baseline and changed CLI sources directly using
the same three pinned owner-built Rust library inputs. Their hashes were checked
again after each run. The compiled tests bind the actual resulting executable
through Cargo's standard `CARGO_BIN_EXE_uma-sim` variable. The compiler command,
binary identities, source identities, raw build output and process receipts are
in `evidence/final-baseline/receipt.json` and
`evidence/final-candidate/receipt.json`.

The borrowed native source tree matches current main in 76 source/manifests.
Its one different file is the existing owner's separately active
`career_lab.rs` checkpoint candidate; that path is not called by these batch
cases and was not edited. `evidence/source-intake.json` preserves the exact
matching and differing identities. Source-file equality alone is not relabeled
as proof of the library's compilation custody. This is a direct native CLI
receiving qualification with explicitly pinned existing dependencies, **not a
fresh full-main Cargo build, hosted CI pass, or deployment**.

The ordinary repository regression command remains:

```sh
cargo test -p uma-sim-core --test batch_output_failures
```

On other platforms, Cargo runs the open-error and successful-output methods;
the native file-size-limit method is Linux x86-64 only. The standalone
`receive.py` packet runner uses the three-case Linux x86-64 result counts.
Exact commands for this receiving run are recorded rather than inferred.

## Custody and integration

All original stderr/stdout/status receipts, the failed controls, directory
sentinels, complete careers and partial career bytes are retained. The archive
excludes compiled executables and caches; their exact identities and rebuild
commands remain in the receipts. It includes the unchanged original CLI source,
candidate source, final and preliminary test sources, reproduction runner,
documentation and exact coordination/readback records.

The source is ready for independent review. Publication, fresh head/collision
checks, hosted gates and integration remain with the parent after the existing
content-creation throttle clears. No source branch or PR is claimed by this
local packet.
