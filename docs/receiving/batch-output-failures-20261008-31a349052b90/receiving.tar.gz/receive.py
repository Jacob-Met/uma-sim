#!/usr/bin/env python3
"""Build and receive the real CLI using an explicitly selected native cache.

The standard repository regression command remains Cargo test. This isolated
runner never writes the supplied compiler, dependency cache or data tree.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def invoke(command, *, cwd, env):
    start = time.monotonic()
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=90)
    return {
        "command": command,
        "exit_code": result.returncode,
        "seconds": time.monotonic() - start,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", required=True, choices=["baseline", "candidate"])
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--deps", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    (output / "tmp").mkdir()
    source = base / args.stage / "uma-sim.rs"
    tests = base / "batch_output_failures.rs"
    deps = args.deps.resolve()
    chosen = {}
    for name in ["uma_sim_core", "serde", "serde_json"]:
        paths = sorted(deps.glob(f"lib{name}-*.rlib"))
        if len(paths) != 1:
            raise SystemExit(f"Expected one {name} dependency, got {paths}")
        chosen[name] = paths[0]
    receipts = {
        "stage": args.stage,
        "source": {"path": str(source), "sha256": digest(source)},
        "tests": {"path": str(tests), "sha256": digest(tests)},
        "compiler": {"path": str(args.rustc), "sha256": digest(args.rustc)},
        "dependencies": [{"path": str(path), "sha256": digest(path)} for path in chosen.values()],
        "data_root": str(args.data_root.resolve()),
        "scope": "Direct exact-CLI Rust build with read-only existing native library dependencies; not a full current-main Cargo build or hosted CI run.",
    }
    env = dict(os.environ, TMPDIR=str(output / "tmp"))
    compiler = str(args.rustc.resolve())
    flags = ["--edition=2021", "-L", "dependency=" + str(deps), "-C", "debuginfo=0", "-C", "strip=symbols"]
    binary = output / "uma-sim"
    command = [compiler, "--crate-name", "uma_sim", str(source), *flags]
    for name, path in chosen.items():
        command += ["--extern", f"{name}={path}"]
    command += ["-o", str(binary)]
    receipts["cli_build"] = invoke(command, cwd=base, env=env)
    if receipts["cli_build"]["exit_code"]:
        (output / "receipt.json").write_text(json.dumps(receipts, indent=2) + "\n")
        raise SystemExit("CLI build failed; see receipt.json")
    receipts["binary_sha256"] = digest(binary)
    env["CARGO_MANIFEST_DIR"] = str(args.data_root.resolve() / "uma-sim-core")
    env["CARGO_BIN_EXE_uma-sim"] = str(binary)
    test_binary = output / "batch-output-tests"
    command = [compiler, "--test", "--crate-name", "batch_output_failures", str(tests), *flags,
               "--extern", "serde_json=" + str(chosen["serde_json"]), "-o", str(test_binary)]
    receipts["test_build"] = invoke(command, cwd=base, env=env)
    if receipts["test_build"]["exit_code"]:
        (output / "receipt.json").write_text(json.dumps(receipts, indent=2) + "\n")
        raise SystemExit("Test build failed; see receipt.json")
    env["UMA_BATCH_RECEIVING_ROOT"] = str(output / "cases")
    env["UMA_BATCH_DATA_ROOT"] = str(args.data_root.resolve())
    receipts["test_run"] = invoke([str(test_binary), "--test-threads=1", "--nocapture"], cwd=base, env=env)
    receipts["inputs_unchanged"] = all(digest(row["path"]) == row["sha256"] for row in receipts["dependencies"])
    receipts["inputs_unchanged"] &= digest(source) == receipts["source"]["sha256"] and digest(tests) == receipts["tests"]["sha256"]
    expected = "1 passed; 2 failed;" if args.stage == "baseline" else "3 passed; 0 failed;"
    receipts["expected_result_observed"] = expected in receipts["test_run"]["stdout"] and receipts["inputs_unchanged"]
    (output / "receipt.json").write_text(json.dumps(receipts, indent=2) + "\n")
    (output / "test.stdout").write_text(receipts["test_run"]["stdout"])
    (output / "test.stderr").write_text(receipts["test_run"]["stderr"])
    print(json.dumps({"stage": args.stage, "output": str(output), "binary_sha256": receipts["binary_sha256"],
                      "test_sha256": receipts["tests"]["sha256"], "test_exit": receipts["test_run"]["exit_code"],
                      "expected_result_observed": receipts["expected_result_observed"], "stdout": receipts["test_run"]["stdout"]}))
    if not receipts["expected_result_observed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
