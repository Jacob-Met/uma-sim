#!/usr/bin/env python3
"""Verify retained source, native receipts and output identities offline."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / "packet-manifest.json").read_text())
for row in manifest["files"]:
    data = (root / row["path"]).read_bytes()
    assert len(data) == row["bytes"], row["path"]
    assert hashlib.sha256(data).hexdigest() == row["sha256"], row["path"]

inputs = json.loads((root / "publication-inputs.json").read_text())
for row in inputs["files"]:
    data = (root / row["source"]).read_bytes()
    assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == row["git_blob"]

results = {}
for stage in ["baseline", "candidate"]:
    receipt = json.loads((root / "evidence" / ("final-" + stage) / "receipt.json").read_text())
    assert receipt["expected_result_observed"] and receipt["inputs_unchanged"]
    cases = root / "evidence" / ("final-" + stage) / "cases"
    matching = list(cases.glob("batch-output-midstream-*"))
    assert len(matching) == 1
    partial = (matching[0] / "partial.jsonl").read_bytes()
    complete = (matching[0] / "complete.jsonl").read_bytes()
    assert partial == complete[:len(partial)]
    assert partial.count(b"\n") == 1 and complete.count(b"\n") == 3
    results[stage] = (partial, complete, receipt["tests"]["sha256"])
assert results["baseline"] == results["candidate"]
print(json.dumps({"manifest_files_verified": len(manifest["files"]), "source_files_verified": len(inputs["files"]),
                  "identical_final_test_source": True, "partial_bytes": len(results["candidate"][0]),
                  "complete_bytes": len(results["candidate"][1]), "network_calls": 0}))
