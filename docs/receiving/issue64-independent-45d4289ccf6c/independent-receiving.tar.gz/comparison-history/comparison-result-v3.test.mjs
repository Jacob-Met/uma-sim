import assert from "node:assert/strict";
import { after, test } from "node:test";
import React from "react";
import TestRenderer, { act } from "react-test-renderer";
import { loadUiModule, cleanCompiledUi } from "./compile-ui.mjs";

const { ComparePanel } = loadUiModule("components/ComparePanel");
const { useLabStore } = loadUiModule("state/labStore");
after(cleanCompiledUi);

const branch = (id) => ({
  id, name: id.toUpperCase(), checkpointName: "start", seed: 7,
  scenarioId: "ura", traineeName: "Special Week", policy: "bot",
  steps: 1, careerComplete: false, finalTurn: 1, fans: 100,
  startedAt: "2026-10-08T00:00:00Z",
});
const outcome = {
  steps: 1, finalTurn: 1, careerComplete: false, completedRaces: [],
  stats: { speed: 100, stamina: 100, power: 100, guts: 100, wit: 100 },
  energy: 100, mood: "NORMAL", fans: 100, skillPoints: 0,
  learnedSkills: [], sparks: [], scenarioResources: {}, totalRngCalls: 1,
  telemetryRecords: 1,
};
const comparison = (a, b) => ({
  aId: a, aName: a.toUpperCase(), bId: b, bName: b.toUpperCase(),
  checkpointName: "start", checkpointTurn: 0, seed: 7,
  sameCheckpoint: true, comparedAt: "2026-10-08T00:00:00Z",
  firstDivergence: null, aligned: [], outcomeA: outcome, outcomeB: outcome,
  caveats: [],
});

function deferred() {
  let resolve;
  const promise = new Promise((settle) => { resolve = settle; });
  return { promise, resolve };
}

/** Mount the real panel and real hook; replace only their HTTP boundary. */
async function mount(t) {
  let entries = ["alpha", "beta", "gamma"].map(branch);
  let latest;
  let pendingComparison = null;
  let holdNextComparison = false;
  let failNextBranchList = false;
  let failedBranchLists = 0;
  let failNextDelete = false;
  let renderer;
  const requests = [];
  const originalFetch = globalThis.fetch;
  const originalWindow = globalThis.window;
  globalThis.window = { confirm: () => true };
  globalThis.fetch = async (path, init = {}) => {
    const body = init.body === undefined ? null : JSON.parse(init.body);
    requests.push({ path, method: init.method, body });
    let data;
    let status = 200;
    if (path === "/v1/sessions") data = { sessions: [], active: "" };
    else if (path === "/v1/library") data = { entries: [] };
    else if (path === "/v1/lab/branches") {
      if (failNextBranchList) {
        failNextBranchList = false;
        failedBranchLists += 1;
        status = 503;
        data = { error: "fixture branch reload failed" };
      } else data = { branches: entries };
    }
    else if (path === "/v1/lab/branch/delete") {
      assert.ok(entries.some((entry) => entry.id === body.id), "delete must name an existing fixture branch");
      if (failNextDelete) {
        failNextDelete = false;
        status = 503;
        data = { error: "fixture delete failed" };
      } else {
        entries = entries.filter((entry) => entry.id !== body.id);
        data = { deleted: body.id };
      }
    } else if (path === "/v1/lab/compare") {
      assert.ok(entries.some((entry) => entry.id === body.a));
      assert.ok(entries.some((entry) => entry.id === body.b));
      data = comparison(body.a, body.b);
      if (holdNextComparison) {
        holdNextComparison = false;
        const gate = deferred();
        pendingComparison = { gate, data };
        await gate.promise;
        pendingComparison = null;
      }
    } else throw new Error(`Unexpected fixture request: ${init.method} ${path}`);
    return new Response(JSON.stringify(data), {
      status, headers: { "content-type": "application/json" },
    });
  };
  t.after(async () => {
    // Release only this test's held response on assertion failure before unmount.
    if (pendingComparison) pendingComparison.gate.resolve();
    if (renderer) await act(async () => { renderer.unmount(); });
    globalThis.fetch = originalFetch;
    if (originalWindow === undefined) delete globalThis.window;
    else globalThis.window = originalWindow;
  });
  function Harness() {
    latest = useLabStore(async () => {});
    return React.createElement(ComparePanel, { lab: latest });
  }
  await act(async () => { renderer = TestRenderer.create(React.createElement(Harness)); });
  await act(async () => { await latest.reloadAll(); });

  return {
    get state() { return latest.state; },
    get failedBranchLists() { return failedBranchLists; },
    requests,
    select: async (side, id) => {
      await act(async () => {
        renderer.root.findByProps({ "aria-label": `Compare ${side}: ${id.toUpperCase()}` }).props.onChange();
      });
    },
    compare: async () => {
      await act(async () => {
        renderer.root.findAllByType("button")
          .find((button) => button.children.join("") === "Compare selected branches").props.onClick();
      });
    },
    delete: async (id) => {
      await act(async () => {
        const row = renderer.root.findAllByType("tr").find((item) => {
          const cells = item.findAllByType("td");
          return cells.length > 0 && cells[0].children.join("") === id.toUpperCase();
        });
        assert.ok(row, `rendered branch ${id} must exist`);
        const button = row.findByType("button");
        assert.equal(button.props.disabled, false, "ordinary delete uses an enabled real panel control");
        button.props.onClick();
      });
    },
    links: () => renderer.root.findAllByType("a").filter((link) =>
      link.children.join("").startsWith("Download ")).map((link) => new URL(link.props.href, "http://fixture.local")),
    heading: () => renderer.root.findAllByType("h3").map((heading) => heading.children.join("")),
    holdComparison: () => { holdNextComparison = true; },
    failBranchList: () => { failNextBranchList = true; },
    failDelete: () => { failNextDelete = true; },
    // These methods deliberately exercise overlapping public hook calls. The
    // ordinary UI uses a busy overlay; no pointer-reachability claim is made.
    beginCompare: (a, b) => {
      let completion;
      act(() => { completion = latest.compare(a, b); });
      assert.ok(pendingComparison, "fixture must hold the actual compare response");
      return completion;
    },
    deleteThroughHook: async (id) => {
      await act(async () => { await latest.deleteBranch(id); });
    },
    compareThroughHook: async (a, b) => {
      await act(async () => { await latest.compare(a, b); });
    },
    deleteAllowingRefreshError: async (id) => {
      // Older source rejects outside its busy wrapper. Capture that rejection
      // so the assertion measures the committed deletion's displayed state.
      let error;
      await act(async () => {
        try { await latest.deleteBranch(id); }
        catch (caught) { error = caught; }
      });
      return error;
    },
    releaseComparison: async (completion) => {
      assert.ok(pendingComparison, "there must be an outstanding comparison response");
      await act(async () => { pendingComparison.gate.resolve(); await completion; });
    },
  };
}

async function compareAB(h) {
  await h.select("A", "alpha");
  await h.select("B", "beta");
  await h.compare();
  assert.deepEqual([h.state.comparison?.aId, h.state.comparison?.bId], ["alpha", "beta"]);
  assert.ok(h.heading().includes("ALPHA vs BETA"));
}

function assertExports(h, a, b) {
  const links = h.links();
  assert.equal(links.length, 2, "both report formats must remain available");
  assert.deepEqual(links.map((link) => link.searchParams.get("format")).sort(), ["json", "markdown"]);
  for (const link of links) {
    assert.equal(link.pathname, "/v1/lab/report");
    assert.deepEqual([link.searchParams.get("a"), link.searchParams.get("b")], [a, b],
      "report IDs must identify the displayed comparison");
  }
}

test("changing radios retains exports for the displayed A/B result", async (t) => {
  const h = await mount(t);
  await compareAB(h);
  assertExports(h, "alpha", "beta");
  await h.select("B", "gamma");
  assert.deepEqual([h.state.compareA, h.state.compareB], ["alpha", "gamma"]);
  assert.ok(h.heading().includes("ALPHA vs BETA"));
  assertExports(h, "alpha", "beta");
});

for (const [side, id] of [["A", "alpha"], ["B", "beta"]]) {
  test(`deleting compared ${side} clears its result after that radio changes`, async (t) => {
    const h = await mount(t);
    await compareAB(h);
    await h.select(side, "gamma");
    await h.delete(id);
    assert.equal(h.state.branches.some((entry) => entry.id === id), false);
    assert.equal(h.state.comparison, null, "a deleted compared identity cannot keep a displayed result");
    assert.deepEqual(h.links(), []);
    assert.equal(h.heading().includes("ALPHA vs BETA"), false);
  });
}

test("deleting selected C retains the unrelated displayed A/B comparison", async (t) => {
  const h = await mount(t);
  await compareAB(h);
  const displayed = h.state.comparison;
  await h.select("B", "gamma");
  await h.delete("gamma");
  assert.equal(h.state.branches.some((entry) => entry.id === "gamma"), false);
  assert.deepEqual(h.state.comparison, displayed, "deletion identity is taken from the result, not current radios");
  assert.ok(h.heading().includes("ALPHA vs BETA"));
  assertExports(h, "alpha", "beta");
});

test("a successful fresh A/C comparison updates display and both exports", async (t) => {
  const h = await mount(t);
  await compareAB(h);
  await h.select("B", "gamma");
  await h.compare();
  assert.deepEqual([h.state.comparison?.aId, h.state.comparison?.bId], ["alpha", "gamma"]);
  assert.ok(h.heading().includes("ALPHA vs GAMMA"));
  assertExports(h, "alpha", "gamma");
  assert.deepEqual(h.requests.filter((request) => request.path === "/v1/lab/compare").map((request) => request.body),
    [{ a: "alpha", b: "beta" }, { a: "alpha", b: "gamma" }]);
});

test("a delayed compare response cannot restore a successfully deleted branch", async (t) => {
  const h = await mount(t);
  h.holdComparison();
  const completion = h.beginCompare("alpha", "beta");
  await h.deleteThroughHook("beta");
  assert.equal(h.state.branches.some((entry) => entry.id === "beta"), false);
  await h.releaseComparison(completion);
  assert.equal(h.state.comparison, null, "the late A/B response must not restore deleted B");
  assert.deepEqual(h.links(), []);
});

test("confirmed deletion invalidates its comparison even when branch reload fails", async (t) => {
  const h = await mount(t);
  await compareAB(h);
  h.failBranchList();
  await h.deleteAllowingRefreshError("beta");
  assert.equal(h.failedBranchLists, 1, "the fallible read after successful deletion was exercised");
  assert.equal(h.requests.filter((request) => request.path === "/v1/lab/branch/delete").length, 1);
  assert.equal(h.state.comparison, null, "successful deletion must invalidate the result before refreshing the list");
  assert.deepEqual(h.links(), []);
});

test("a refused deletion retains the displayed result, selections, and branch list", async (t) => {
  const h = await mount(t);
  await compareAB(h);
  const before = { comparison: h.state.comparison, branches: h.state.branches,
    a: h.state.compareA, b: h.state.compareB };
  const listRequests = h.requests.filter((request) => request.path === "/v1/lab/branches").length;
  h.failDelete();
  await h.delete("beta");
  assert.match(h.state.error, /fixture delete failed/);
  assert.deepEqual({ comparison: h.state.comparison, branches: h.state.branches,
    a: h.state.compareA, b: h.state.compareB }, before);
  assert.equal(h.requests.filter((request) => request.path === "/v1/lab/branches").length, listRequests);
  assertExports(h, "alpha", "beta");
});

test("deleting unrelated C does not cancel a pending A/B comparison", async (t) => {
  const h = await mount(t);
  h.holdComparison();
  const completion = h.beginCompare("alpha", "beta");
  await h.deleteThroughHook("gamma");
  assert.equal(h.state.branches.some((entry) => entry.id === "gamma"), false);
  await h.releaseComparison(completion);
  assert.deepEqual([h.state.comparison?.aId, h.state.comparison?.bId], ["alpha", "beta"]);
  assertExports(h, "alpha", "beta");
});

test("an older successful comparison cannot replace a newer completed result", async (t) => {
  const h = await mount(t);
  h.holdComparison();
  const older = h.beginCompare("alpha", "beta");
  await h.compareThroughHook("alpha", "gamma");
  assert.deepEqual([h.state.comparison?.aId, h.state.comparison?.bId], ["alpha", "gamma"]);
  await h.releaseComparison(older);
  assert.deepEqual([h.state.comparison?.aId, h.state.comparison?.bId], ["alpha", "gamma"]);
  assertExports(h, "alpha", "gamma");
});
