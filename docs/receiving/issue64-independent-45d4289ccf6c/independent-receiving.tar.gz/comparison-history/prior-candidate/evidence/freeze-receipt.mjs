import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const base = '/workspace/scratch/45d4289ccf6c/agents/production_recovery/uma-session-composition';
const src = `${base}/source`;
const ev = `${base}/evidence`;
const read = (name) => JSON.parse(fs.readFileSync(path.join(ev, name), 'utf8'));
const sha = (p) => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const capture = read('capture.json');
const composition = read('composition-source.json');
const tree = read('owner-tree.json');
const changed = new Set(composition.modified.map((row) => row.path));
let preserved = 0;
for (const row of tree) {
  if (changed.has(row.path)) continue;
  const file = path.join(src, row.path);
  const stat = fs.lstatSync(file);
  const bytes = stat.isSymbolicLink() ? Buffer.from(fs.readlinkSync(file)) : fs.readFileSync(file);
  const mode = stat.isSymbolicLink() ? '120000' : stat.mode & 0o111 ? '100755' : '100644';
  const blob = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
  if (blob !== row.blob || mode !== row.mode) throw new Error(`Unrelated source changed: ${row.path}`);
  preserved++;
}
for (const row of composition.modified) {
  if (sha(path.join(src, row.path)) !== row.afterSha256) throw new Error(`Composed source changed: ${row.path}`);
}
const ownerAfter = {
  head: execFileSync('git', ['-C', capture.ownerSource, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  status: execFileSync('git', ['-C', capture.ownerSource, 'status', '--porcelain=v1', '--untracked-files=all'], { encoding: 'utf8' }),
};
const ui = `${src}/packages/uma-sim-ui`;
const lock = JSON.parse(fs.readFileSync(`${ui}/package-lock.json`, 'utf8'));
const versions = {};
for (const name of ['react', 'react-dom', 'react-test-renderer', 'typescript', 'vite']) {
  const actual = JSON.parse(fs.readFileSync(`${ui}/node_modules/${name}/package.json`, 'utf8')).version;
  if (actual !== lock.packages[`node_modules/${name}`].version) throw new Error(`Native dependency diverges from lock: ${name}`);
  versions[name] = actual;
}
const logs = {};
for (const name of ['combined-tests.log', 'typecheck.log', 'build.log']) logs[name] = { sha256: sha(path.join(ev, name)) };
const built = fs.readdirSync(`${ui}/dist/assets`).map((name) => ({
  path: `packages/uma-sim-ui/dist/assets/${name}`, sha256: sha(`${ui}/dist/assets/${name}`),
}));
built.push({ path: 'packages/uma-sim-ui/dist/index.html', sha256: sha(`${ui}/dist/index.html`) });
const receipt = {
  reviewer: 'estate-45d4289ccf6c/production_recovery',
  purpose: 'Independent prospective compatibility of existing issue63 source and accepted comparison result source',
  decision: 'compatible within qualified native UI/package scope',
  ownerSource: {
    identity: capture.ownerIdentity, commit: capture.committedSource,
    archiveSha256: capture.archiveSha256, cleanAtCapture: true,
    afterQualification: ownerAfter,
    unchanged: ownerAfter.head === capture.committedSource && ownerAfter.status === '',
  },
  comparisonSource: composition.modified.filter((row) => row.path.endsWith('.ts') || row.path.endsWith('.tsx')),
  compositionDelta: composition.modified,
  unrelatedOwnerLeavesPreservedAtFinalReadback: preserved,
  generatedTrackedBuildArtifact: read('generated-build-metadata.json'),
  helperSha256: composition.loaderSha256,
  sessionTestSha256: composition.sessionTestSha256,
  lockSha256: composition.lockSha256,
  nativeRuntime: { node: process.version, ...versions },
  qualification: [
    { command: 'npm test', exitCode: 0, tests: 23, passed: 23, failed: 0, skipped: 0, cancelled: 0, sessionTests: 13, comparisonTests: 10 },
    { command: 'npm run typecheck', exitCode: 0 },
    { command: 'npm run build', exitCode: 0, prebuildTests: 23, prebuildPassed: 23, modules: 52 },
  ],
  integrationFinding: {
    previousOwnerCorrection: 'faf80aaa656fb1ac9d21cfcc79fc48b8c6c8963e replaces shell wildcard with explicit test filename',
    requiredComposedScript: 'node --test tests/run-session.test.mjs tests/comparison-result.test.mjs',
    standaloneScript: 'node --test tests/comparison-result.test.mjs',
    scope: 'Preserves the owner source portability correction; no Windows execution is claimed',
  },
  logs, builtArtifacts: built,
  limits: [
    'Real React hooks/client/App and comparison panel with deterministic fixture transports; no live session, inference, browser-layout or production action was performed.',
    'Rust API source is retained exactly from the owner commit; this composition did not rerun its separate Rust native qualification.',
    'This isolated composition is not source adoption, remote publication, merge authority or deployment.',
    'Actual TypeScript build changed one owner-tracked incremental metadata file. Its produced bytes are retained; only that isolated generated file was restored before final source readback.',
  ],
  ownerSourceModified: false, remoteMutations: false,
};
fs.writeFileSync(`${ev}/compatibility-receipt.json`, JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify({ decision: receipt.decision, ownerCommit: capture.committedSource,
  ownerUnchanged: receipt.ownerSource.unchanged, preservedOwnerLeaves: preserved,
  tests: 23, typecheck: 'pass', build: 'pass', receipt: `${ev}/compatibility-receipt.json` }, null, 2));
