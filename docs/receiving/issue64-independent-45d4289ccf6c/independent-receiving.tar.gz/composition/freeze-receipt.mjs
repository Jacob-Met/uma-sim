import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = '/workspace/scratch/45d4289ccf6c/agents/production_recovery';
const base = `${root}/uma-63-64-composition`;
const evidence = `${base}/evidence`;
const source = `${base}/source`;
const ui = `${source}/packages/uma-sim-ui`;
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const shaBytes = b => createHash('sha256').update(b).digest('hex');
const sha = p => shaBytes(fs.readFileSync(p));
const blob = b => createHash('sha1').update(`blob ${b.length}\0`).update(b).digest('hex');
const capture = read(`${evidence}/composition-capture.json`);
const tree = read(`${evidence}/owner63-tree.json`);
const generated = fs.readFileSync(`${ui}/tsconfig.tsbuildinfo`);
const committed = fs.readFileSync(`${evidence}/owner63-committed.tsbuildinfo`);
assert.equal(blob(committed), tree.find(row => row.path === 'packages/uma-sim-ui/tsconfig.tsbuildinfo').blob);
fs.writeFileSync(`${evidence}/tsconfig-after-build.tsbuildinfo`, generated, { flag: 'wx' });
fs.writeFileSync(`${ui}/tsconfig.tsbuildinfo`, committed);
const changed = new Set(capture.sourceDeltaAgainst63.map(row => row.path));
let preserved = 0;
for (const row of tree) {
  if (changed.has(row.path)) continue;
  const p = `${source}/${row.path}`;
  const stat = fs.lstatSync(p);
  const bytes = stat.isSymbolicLink() ? Buffer.from(fs.readlinkSync(p)) : fs.readFileSync(p);
  const mode = stat.isSymbolicLink() ? '120000' : stat.mode & 0o111 ? '100755' : '100644';
  assert.equal(mode, row.mode, `Unrelated owner63 mode ${row.path}`);
  assert.equal(blob(bytes), row.blob, `Unrelated owner63 source ${row.path}`);
  preserved++;
}
for (const row of capture.sourceDeltaAgainst63) {
  assert.equal(sha(`${source}/${row.path}`), row.afterSha256);
  if (row.origin) assert.equal(sha(row.origin), row.afterSha256);
}
const owner63 = capture.source63.origin;
const owner63After = {
  head: execFileSync('git', ['-C', owner63, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  status: execFileSync('git', ['-C', owner63, 'status', '--porcelain=v1', '--untracked-files=all'], { encoding: 'utf8' }),
};
assert.equal(owner63After.head, capture.source63.commit);
assert.equal(owner63After.status, '');
const tests = {};
for (const [name, expectedTests] of [['build.log', 42], ['comparison-receiving.log', 11], ['override-receiving.log', 13]]) {
  const log = fs.readFileSync(`${evidence}/${name}`, 'utf8');
  const result = { commandLog: name, logSha256: sha(`${evidence}/${name}`), exitCode: 0 };
  for (const key of ['tests', 'pass', 'fail', 'cancelled', 'skipped']) {
    const match = log.match(new RegExp(`^ℹ ${key} (\\d+)$`, 'm'));
    assert(match); result[key] = Number(match[1]);
  }
  assert.equal(result.tests, expectedTests); assert.equal(result.pass, expectedTests); assert.equal(result.fail, 0);
  tests[name] = result;
}
assert(fs.readFileSync(`${evidence}/build.log`, 'utf8').includes('53 modules transformed.'));
const receipt = {
  reviewer: 'estate-45d4289ccf6c/production_recovery', frozenAt: new Date().toISOString(),
  disposition: 'Compatible prospective native package composition of exact issue63 commit and independently frozen issue64 source',
  source63: { ...capture.source63, finalReadback: owner63After, ownerSourceUnchanged: true },
  source64: capture.source64, sourceDeltaAgainst63: capture.sourceDeltaAgainst63,
  ownership: 'Issue64 remains canonical source owner; no alternative source implementation or source PR is produced by this receiving',
  unrelatedOwner63SourceLeavesAndModesPreserved: preserved,
  retainedTests: {
    session: { path: 'packages/uma-sim-ui/tests/run-session.test.mjs', cases: 13, sha256: sha(`${ui}/tests/run-session.test.mjs`) },
    parser: { path: 'packages/uma-sim-ui/tests/branch-input.test.mjs', cases: 29, sha256: sha(`${ui}/tests/branch-input.test.mjs`) },
    browserReceiver: { path: 'packages/uma-sim-ui/tests/receiving/uma-lab-receiver.mjs', sha256: sha(`${ui}/tests/receiving/uma-lab-receiver.mjs`), executedHere: false },
    sharedLoader: { path: 'packages/uma-sim-ui/tests/compile-ui.mjs', sha256: sha(`${ui}/tests/compile-ui.mjs`) },
  },
  testRegistration: capture.testRegistration,
  independentReceiving: { comparisonCases: 11, overrideFormCases: 13, bothExecutedAgainstComposedSource: true, registeredInCi: false },
  dependencyComposition: capture.dependencyComposition,
  qualification: { tests, typecheck: { command: 'npm run typecheck', exitCode: 0, logSha256: sha(`${evidence}/typecheck.log`) },
    build: { command: 'npm run build', exitCode: 0, prebuildTests: 42, modules: 53 } },
  generatedTrackedMetadata: { path: 'packages/uma-sim-ui/tsconfig.tsbuildinfo',
    committedSha256: shaBytes(committed), generatedSha256: shaBytes(generated), generatedBytes: generated.length,
    action: 'Preserved actual generated output, then restored only isolated composition metadata before final source readback' },
  builtArtifacts: [...fs.readdirSync(`${ui}/dist/assets`).map(p => `packages/uma-sim-ui/dist/assets/${p}`), 'packages/uma-sim-ui/dist/index.html']
    .map(p => ({ path: p, sha256: sha(`${source}/${p}`) })),
  owner63Bundle: { path: `${evidence}/owner63-session.bundle`, sha256: sha(`${evidence}/owner63-session.bundle`),
    prerequisite: 'f5f9b29393731d18aee2d66a31d89c315aa79c60', head: capture.source63.commit, verifiedAgainstOriginalRepository: true },
  setupFailurePreserved: { receipt: `${evidence}/preparation-failure.json`, cause: 'Declared Playwright was absent from the production directory runtime',
    resolution: 'Read-only reuse of matching Playwright1.62.1 from the owner integration runtime; source pins and lock entries stayed exact' },
  limits: [
    'This prospective composition uses exact frozen initial issue64 file hashes. Its later trace/current-main candidate and eventual published Git head remain pending separate readback.',
    'The 42 native cases and both independent receivers executed real TypeScript/React on fixture HTTP boundaries. No live career/session, inference, Rust-server or deployed-service action was performed.',
    'This is a native UI/package composition, not a Git merge or reproduction of repository CI. Unrelated issue63 source is preserved; the separate Rust suite was not rerun.',
    'Existing owner browser/API receiving is retained; this worker does not substitute the fixture/component run for that browser qualification.'
  ],
  sourceOwnerEdits: false, remoteSourceMutations: false,
};
fs.writeFileSync(`${evidence}/compatibility-receipt.json`, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
for (const p of ['package.json', 'package-lock.json']) fs.copyFileSync(`${ui}/${p}`, `${evidence}/composed-${p}`);
console.log(JSON.stringify({ receipt: `${evidence}/compatibility-receipt.json`, sha256: sha(`${evidence}/compatibility-receipt.json`),
  cases: 42, independentComparison: 11, independentOverrideForm: 13, preservedSourceLeaves: preserved,
  sourceOwnerUnchanged: true, typecheck: 'pass', build: 'pass', generatedMetadataSha256: shaBytes(generated) }, null, 2));
