import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = '/workspace/scratch/45d4289ccf6c/agents/production_recovery';
const base = `${root}/uma-63-64-composition`;
const source = `${base}/source`;
const ui = `${source}/packages/uma-sim-ui`;
const evidence = `${base}/evidence`;
const owner63 = '/workspace/scratch/69570d292200/agents/production/uma-sim';
const owner64 = '/workspace/scratch/7e7ad6f8e5bd/production/uma-sim/packages/uma-sim-ui';
const installed64 = '/workspace/scratch/7e7ad6f8e5bd/integration/uma-ui';
const source64 = `${root}/uma-override-receiving/source-owner/src`;
const pin63 = 'f5d65944dc327087b235b6917c5ce9f94947e24e';
const sha = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const git = (...args) => execFileSync('git', ['-C', owner63, ...args], { encoding: 'utf8' });
assert.equal(git('rev-parse', 'HEAD').trim(), pin63);
assert.equal(git('status', '--porcelain=v1', '--untracked-files=all'), '');
fs.mkdirSync(evidence, { recursive: true });
fs.mkdirSync(source, { recursive: true });
const archive = `${evidence}/owner63-source.tar`;
execFileSync('git', ['-C', owner63, 'archive', '--format=tar', `--output=${archive}`, pin63]);
execFileSync('tar', ['-xf', archive, '-C', source]);
const tree = git('ls-tree', '-r', '-z', pin63).split('\0').filter(Boolean).map(line => {
  const [meta, name] = line.split('\t'); const [mode, type, blob] = meta.split(' ');
  return { path: name, mode, type, blob };
});
const delta = [];
function overlay(relative, origin) {
  const destination = `${ui}/${relative}`;
  const beforeSha256 = fs.existsSync(destination) ? sha(destination) : null;
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.copyFileSync(origin, destination);
  delta.push({ path: `packages/uma-sim-ui/${relative}`, beforeSha256, afterSha256: sha(destination), origin });
}
for (const p of ['components/ComparePanel.tsx', 'components/branchInput.ts', 'state/labStore.ts']) {
  assert.equal(sha(`${source64}/${p}`), sha(`${owner64}/src/${p}`), `Owner64 source changed before composition: ${p}`);
  overlay(`src/${p}`, `${source64}/${p}`);
}
for (const p of ['tests/branch-input.test.mjs', 'tests/receiving/uma-lab-receiver.mjs']) overlay(p, `${owner64}/${p}`);
const packagePath = `${ui}/package.json`;
const lockPath = `${ui}/package-lock.json`;
const pkg63 = read(packagePath);
const pkg64 = read(`${owner64}/package.json`);
const lock63 = read(lockPath);
const lock64 = read(`${owner64}/package-lock.json`);
const originalPackageSha = sha(packagePath);
const originalLockSha = sha(lockPath);
const dependencies = { ...pkg63.devDependencies, ...pkg64.devDependencies };
for (const [name, version] of Object.entries(pkg63.devDependencies)) {
  if (name in pkg64.devDependencies) assert.equal(version, pkg64.devDependencies[name], `Conflicting dependency declaration: ${name}`);
}
const commonLockEntries = [];
const addedLockEntries = [];
for (const [name, value] of Object.entries(lock64.packages)) {
  if (!name) continue;
  if (name in lock63.packages) {
    assert.deepEqual(value, lock63.packages[name], `Conflicting locked dependency: ${name}`);
    commonLockEntries.push(name);
  } else { lock63.packages[name] = value; addedLockEntries.push({ path: name, version: value.version }); }
}
pkg63.devDependencies = dependencies;
pkg63.scripts.test = 'node --test tests/run-session.test.mjs tests/branch-input.test.mjs';
pkg63.scripts['test:browser'] = pkg64.scripts['test:browser'];
assert.equal(pkg63.scripts.prebuild, 'npm test');
lock63.packages[''].devDependencies = dependencies;
lock63.packages = Object.fromEntries(Object.entries(lock63.packages).sort(([a], [b]) => a.localeCompare(b)));
fs.writeFileSync(packagePath, JSON.stringify(pkg63, null, 2) + '\n');
fs.writeFileSync(lockPath, JSON.stringify(lock63, null, 2) + '\n');
delta.push({ path: 'packages/uma-sim-ui/package.json', beforeSha256: originalPackageSha, afterSha256: sha(packagePath),
  detail: 'Union of exact owner declarations; retain session prebuild and explicit filenames, retain owner64 browser receiver script' });
delta.push({ path: 'packages/uma-sim-ui/package-lock.json', beforeSha256: originalLockSha, afterSha256: sha(lockPath),
  detail: 'Exact common entries retained; add only owner64 Playwright closure and its unchanged integrity metadata' });
execFileSync('cp', ['-a', '--reflink=auto', `${root}/uma-session-composition-v4/source/packages/uma-sim-ui/node_modules`, `${ui}/node_modules`]);
for (const name of ['playwright', 'playwright-core']) {
  execFileSync('cp', ['-a', '--reflink=auto', `${installed64}/node_modules/${name}`, `${ui}/node_modules/${name}`]);
}
const actualVersions = {};
for (const name of Object.keys({ ...pkg63.dependencies, ...pkg63.devDependencies })) {
  actualVersions[name] = read(`${ui}/node_modules/${name}/package.json`).version;
  assert.equal(actualVersions[name], lock63.packages[`node_modules/${name}`].version, `Installed dependency differs from exact composed lock: ${name}`);
}
const receipt = {
  preparedAt: new Date().toISOString(), source63: { commit: pin63, origin: owner63, archiveSha256: sha(archive), cleanAtCapture: true },
  source64: { identity: 'estate-7e7ad6f8e5bd / issue64', source: source64,
    custody: `${root}/uma-override-receiving/evidence/source-custody.json`,
    qualification: `${root}/uma-override-receiving/evidence/receiving-receipt.json`, publishedCommit: null,
    limitation: 'Prospective composition of the exact independently frozen initial owner source; later trace/current-main publication remains separately owned and pending its actual pin' },
  scope: 'Package/source compatibility qualification, not a Git merge or adoption of the owner source',
  sourceDeltaAgainst63: delta,
  dependencyComposition: { commonEntriesExactlyPreserved: commonLockEntries.length, addedLockEntries,
    source63LockSha256: originalLockSha, source64LockSha256: sha(`${owner64}/package-lock.json`),
    playwrightInstalledSource: installed64, actualVersions },
  testRegistration: { script: pkg63.scripts.test, nativeSessionCases: 13, nativeParserCases: 29,
    independentComparisonModuleRegisteredInCi: false, reason: 'Existing owner native receiving is preserved; full11 module stays independent evidence until the actual published candidate coverage is known' },
  sourceOwnerEdits: false, remoteSourceMutations: false,
};
fs.writeFileSync(`${evidence}/composition-capture.json`, JSON.stringify(receipt, null, 2) + '\n');
fs.writeFileSync(`${evidence}/owner63-tree.json`, JSON.stringify(tree, null, 2) + '\n');
fs.copyFileSync(`${ui}/tsconfig.tsbuildinfo`, `${evidence}/owner63-committed.tsbuildinfo`);
console.log(JSON.stringify({ source63: pin63, source64Files: delta.slice(0, 3), expectedNativeCases: 42,
  commonLockEntries: commonLockEntries.length, addedLockEntries, actualVersions }, null, 2));
