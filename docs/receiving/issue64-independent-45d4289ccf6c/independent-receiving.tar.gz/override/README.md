# Independent override-form receiving

The requested parser repair already belongs to **estate-7e7ad6f8e5bd / UMA issue #64**. Its exact implementation passes this independent component/request qualification. No competing implementation was created.

| Exact source | Override form cases | Existing comparison cases |
|---|---:|---:|
| Main `0ac14602addd1a4610aa8359896915a34cce5659` | 3 passed, 10 failed | Not repeated here |
| Frozen #64 owner source | 13 passed, 0 failed | 11 passed, 0 failed |

All 24 main UI source leaves match GitHub tree `e7d10088a713d8fbd7391c86050a92898652bdd6`. The owner snapshot contains 25 UI source leaves and matches its existing production and integration copies. Those directories have no Git metadata; this record qualifies exact file bytes and does not invent an owner commit.

## What was reproduced

The actual main component creates a partial branch request when a draft contains a malformed line. A missing turn becomes zero. Fractional and oversized turns reach the request body; empty-action, negative-turn and nonnumeric-turn lines disappear, allowing a request with no overrides. The owner blocks malformed drafts, displays source-line diagnostics linked to the field, retains the authored text and submits one complete request after correction. Blank input, legitimate numeric boundaries, action IDs containing colons and unknown action IDs remain accepted controls.

This receiver mounts the actual `ComparePanel` and `useLabStore`, drives their real form callbacks, and records the API client's serialized request. Only HTTP responses are fixtures. The native REST source confirms `ActionOverride.turn` is `i32`, while its request decoder filters entries through `as_i64` and casts to `i32`. Consequently malformed turns may be discarded or narrowed, rather than necessarily producing a generic 400. The simulator retains ownership of action legality and its existing `overrideRejected` trace.

## Repeat

From this directory's `harness`:

```sh
UMA_UI_TEST_SOURCE=../source-baseline/src UMA_OVERRIDE_EVIDENCE=../evidence/new-baseline-observations.json node --test tests/override-form-receiving.test.mjs
UMA_UI_TEST_SOURCE=../source-owner/src UMA_OVERRIDE_EVIDENCE=../evidence/new-owner-observations.json node --test tests/override-form-receiving.test.mjs
```

The existing exact loader resolves source paths from the working directory. It compiles to an isolated temporary directory and uses the already-installed React 18.3.1, renderer 18.3.1 and TypeScript 5.9.3. The frozen receiving receipt records commands, source hashes, observed requests and logs. This check does not independently rerun the owner's browser/native-Rust, package build or CI gates.

## Integration findings

Preserve the already merged PR #65 comparison source, receiver, evidence and attribution when composing the owner's remaining delta. Its lab store already supplies comparison request and branch-revision guards and passes all 11 established comparison controls. The shared `withBusy` state remains inherited; no general request-lifetime guarantee is claimed.

The owner's package uses a wildcard test command. Issue #63 has an explicit portability correction for that command, so composition should retain explicit filenames and include its existing session suite. Root controls owner reconciliation and source integration. All production source and existing owner records remain untouched.
