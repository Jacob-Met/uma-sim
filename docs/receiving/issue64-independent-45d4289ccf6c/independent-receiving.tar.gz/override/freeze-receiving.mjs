import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const base = '/workspace/scratch/45d4289ccf6c/agents/production_recovery/uma-override-receiving';
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const sha = p => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const custody = read(`${base}/evidence/source-custody.json`);
const observations = Object.fromEntries(['baseline', 'owner'].map(name => [name, read(`${base}/evidence/${name}-observations.json`)]));
const results = {};
for (const name of ['baseline', 'owner', 'owner-comparison']) {
  const file = `${base}/evidence/${name}-tests.log`;
  const text = fs.readFileSync(file, 'utf8');
  const result = { log: file, sha256: sha(file) };
  for (const key of ['tests', 'pass', 'fail', 'cancelled', 'skipped']) {
    const match = text.match(new RegExp(`^ℹ ${key} (\\d+)$`, 'm'));
    assert(match, `${name}: ${key}`);
    result[key] = Number(match[1]);
  }
  result.exitCode = result.fail ? 1 : 0;
  results[name] = result;
}
assert.deepEqual([results.baseline.tests, results.baseline.pass, results.baseline.fail], [13, 3, 10]);
assert.deepEqual([results.owner.tests, results.owner.pass, results.owner.fail], [13, 13, 0]);
assert.deepEqual([results['owner-comparison'].tests, results['owner-comparison'].pass], [11, 11]);
const readback = custody.sources.map(source => ({
  identity: source.identity,
  snapshotsExact: source.files.every(row => sha(`${source.snapshot}/src/${row.path.split('/src/')[1]}`) === row.sha256),
  originalReadbackExact: source.files.every(row => sha(row.origin) === row.sha256),
  files: source.files.length,
}));
assert(readback.every(row => row.snapshotsExact && row.originalReadbackExact));
const owner = custody.sources.find(row => row.identity === 'owner');
const candidateFiles = owner.files.filter(row => /\/components\/(ComparePanel\.tsx|branchInput\.ts)$|\/state\/labStore\.ts$/.test(row.path));
const receipt = {
  reviewer: 'estate-45d4289ccf6c/production_recovery', observedAt: new Date().toISOString(),
  repository: 'Jacob-Met/uma-sim', owner: 'estate-7e7ad6f8e5bd; issue64',
  disposition: 'Accepted exact existing owner parser/form source within independently qualified component/request scope; retain its implementation ownership and authorship',
  ownershipFinding: 'Fresh issue search found #64 before any production edit or competing claim. Existing source already implements the requested product behavior. Work changed to independent receiving.',
  baseline: { commit: custody.main, tree: custody.tree, uiSourceLeavesMatchedToGitTree: 24 },
  candidateFiles, sourceReadback: readback,
  sourceCustody: { path: `${base}/evidence/source-custody.json`, sha256: sha(`${base}/evidence/source-custody.json`),
    limit: 'Existing owner production and integration paths are plain source directories. Exact file bytes are qualified; no unobserved owner commit is inferred.' },
  nativeTests: {
    parserModule: { path: `${base}/harness/tests/override-form-receiving.test.mjs`, sha256: sha(`${base}/harness/tests/override-form-receiving.test.mjs`) },
    comparisonModule: { path: '/workspace/scratch/45d4289ccf6c/agents/production_recovery/uma-comparison-review/comparison-result-v4.test.mjs',
      sha256: sha('/workspace/scratch/45d4289ccf6c/agents/production_recovery/uma-comparison-review/comparison-result-v4.test.mjs') },
    loaderSha256: custody.loaderSha256,
    runtime: { node: process.version, react: '18.3.1', renderer: '18.3.1', typescript: '5.9.3' },
    results,
  },
  baselineFindings: [
    'A mixed valid/malformed draft creates a branch using only the valid lines, with no displayed validation.',
    'An omitted turn before a colon becomes numeric zero in the actual request.',
    'Fractional and out-of-i32-range turns reach the actual HTTP request body.',
    'Empty-action, negative-turn and nonnumeric-turn drafts create a branch with an empty override array.',
    'Blank optional input and ordinary complete input remain healthy controls.'
  ],
  ownerFindings: [
    'Malformed whole drafts create no branch requests; the original text and original line numbers remain visible with linked field validation.',
    'Correcting a malformed line enables one request carrying the complete corrected override list.',
    'Zero and signed-i32 maximum turns, action IDs containing colons, ordinary action order/whitespace, unknown choices and blank input retain their request values.',
    'All 11 existing comparison/result/deletion controls pass on the same frozen owner source.'
  ],
  actualRequestContract: {
    source: custody.engineContract,
    turnRepresentation: 'ActionOverride.turn is i32. handle_lab_branch accepts values through as_i64 then casts to i32; malformed array entries are filter_map omissions.',
    implication: 'Fractional JSON values can be dropped; oversized integer values can narrow to another turn. A generic 400 is not the demonstrated behavior of this receiver.',
    actionLegality: 'The engine resolves the authored action against choices on that turn and records overrideRejected with policy fallback when absent. The UI must retain unknown action IDs for that existing run-level behavior.',
    engineExecutedHere: false,
  },
  integrationFindings: [
    'Current main already contains PR65 at 0ac14602. Preserve its exports, native browser receiver, evidence and authorship when composing the existing #64 delta.',
    'The owner package uses tests/*.test.mjs. Issue63 commit faf80aaa656fb1ac9d21cfcc79fc48b8c6c8963e intentionally replaced that wildcard with explicit filenames; preserve that correction in composition.',
    'The owner labStore already guards comparison completion with a request counter and per-branch revisions. Its shared withBusy boolean/error completion behavior remains inherited; no general request-lifetime qualification is claimed.'
  ],
  observations: Object.fromEntries(['baseline', 'owner'].map(name => [name, { path: `${base}/evidence/${name}-observations.json`,
    sha256: sha(`${base}/evidence/${name}-observations.json`), records: observations[name].observations.length }])),
  limits: [
    'Actual ComparePanel, useLabStore and API-client execution on real React with deterministic HTTP fixture responses. This worker did not rerun a native Rust server or browser for this parser receiving.',
    'The baseline is current PR65 main, so historical pre-PR65 comparison defects are not attributed to it.',
    'This receiving does not reproduce the owner package TypeScript/build/CI gates or qualify its later branch-trace candidate.',
    'No owner production files, package scripts, shared runtimes or remote source branches were modified.'
  ],
  implementationEdits: false, remoteSourceMutations: false,
};
fs.writeFileSync(`${base}/evidence/receiving-receipt.json`, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
const record = {
  schema: 'hamon.external_contribution.v1', worker_id: 'chatgpt-45d4289ccf6c-override-receiving',
  source_route: `chatgpt-workspace:${base}`,
  authority_source: "Jacob's attached HAMON Universal Autonomous Execution Worker mandate; bounded independent receiving delegated by root/45d4289ccf6c",
  identity_kind: 'External source contributor; no resident goal or attempt lease',
  state: 'independent_source_component_receiving_qualified',
  repository: 'Jacob-Met/uma-sim', existing_source_owner: 'estate-7e7ad6f8e5bd / issue64',
  scope: 'Independent exact-source override form and existing comparison receiving; existing parser implementation and source ownership retained',
  source_pins: { baseline: custody.main, baseline_tree: custody.tree, owner_files: candidateFiles.map(({ path, sha256, gitBlob }) => ({ path, sha256, gitBlob })) },
  qualified: { parser_original: { passed: 3, failed: 10 }, parser_owner: { passed: 13, failed: 0 }, comparison_owner: { passed: 11, failed: 0 } },
  receipt: { local_path: `${base}/evidence/receiving-receipt.json`, sha256: sha(`${base}/evidence/receiving-receipt.json`) },
  integration: 'Root handles receiving custody and owner reconciliation; no competing parser branch or production edit',
  excluded: ['owner source mutation', 'labStore request-lifetime implementation', 'engine and action legality rules', 'runtime deployment', 'hamon-ie MCP'],
  updated_at: receipt.observedAt,
};
fs.writeFileSync(`${base}/evidence/native-contribution-record.json`, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ receipt: `${base}/evidence/receiving-receipt.json`, receiptSha256: sha(`${base}/evidence/receiving-receipt.json`),
  testSha256: receipt.nativeTests.parserModule.sha256, results, sourceReadback: readback }, null, 2));
