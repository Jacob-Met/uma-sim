import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const root = '/workspace/scratch/45d4289ccf6c';
const own = `${root}/agents/production_recovery`;
const output = `${own}/uma-override-receiving`;
const nativeBaseline = `${own}/uma-e11-review/source/packages/uma-sim-ui`;
const owner = '/workspace/scratch/7e7ad6f8e5bd/production/uma-sim/packages/uma-sim-ui';
const integration = '/workspace/scratch/7e7ad6f8e5bd/integration/uma-ui';
const tree = JSON.parse(fs.readFileSync(`${output}/evidence/current-main-tree.json`, 'utf8'));
const expected = new Map(tree.tree.filter(row => row.type === 'blob').map(row => [row.path, row]));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const blob = bytes => createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
const sourceRows = [];
for (const [name, origin] of [['baseline', nativeBaseline], ['owner', owner]]) {
  const destination = `${output}/source-${name}`;
  fs.mkdirSync(destination, { recursive: true });
  fs.cpSync(`${origin}/src`, `${destination}/src`, { recursive: true, errorOnExist: true, force: false });
  const rows = [];
  function visit(directory, relative = '') {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const next = path.join(relative, entry.name);
      const full = path.join(directory, entry.name);
      if (entry.isDirectory()) visit(full, next);
      else {
        const bytes = fs.readFileSync(full);
        const record = { path: `packages/uma-sim-ui/src/${next}`, bytes: bytes.length,
          sha256: sha(bytes), gitBlob: blob(bytes), origin: `${origin}/src/${next}` };
        assert.equal(sha(fs.readFileSync(record.origin)), record.sha256);
        if (name === 'baseline') assert.equal(record.gitBlob, expected.get(record.path)?.sha, `Current main source ${next}`);
        rows.push(record);
      }
    }
  }
  visit(`${destination}/src`);
  sourceRows.push({ identity: name, original: origin, snapshot: destination, files: rows });
}
assert.equal(sourceRows[0].files.length, tree.tree.filter(row => row.type === 'blob' && row.path.startsWith('packages/uma-sim-ui/src/')).length);
for (const p of ['components/ComparePanel.tsx', 'components/branchInput.ts', 'state/labStore.ts']) {
  assert.equal(sha(fs.readFileSync(`${owner}/src/${p}`)), sha(fs.readFileSync(`${integration}/src/${p}`)));
}
const contract = [];
for (const p of ['uma-sim-core/src/api.rs', 'uma-sim-core/src/career_lab.rs']) {
  const bytes = fs.readFileSync(`${root}/uma-comparison/${p}`);
  assert.equal(blob(bytes), expected.get(p)?.sha, `Native contract source ${p}`);
  contract.push({ path: p, sha256: sha(bytes), gitBlob: blob(bytes) });
}
fs.mkdirSync(`${output}/harness/tests`, { recursive: true });
fs.copyFileSync(`${own}/uma-ui-baseline/packages/uma-sim-ui/tests/compile-ui.mjs`, `${output}/harness/tests/compile-ui.mjs`);
fs.writeFileSync(`${output}/harness/package.json`, '{"private":true,"type":"module"}\n', { flag: 'wx' });
fs.symlinkSync(`${own}/uma-ui-baseline/packages/uma-sim-ui/node_modules`, `${output}/harness/node_modules`, 'dir');
const record = {
  capturedAt: new Date().toISOString(), main: '0ac14602addd1a4610aa8359896915a34cce5659', tree: tree.sha,
  sources: sourceRows, engineContract: contract,
  ownerIdentity: 'estate-7e7ad6f8e5bd; UMA issue64',
  ownerSourceCustody: 'Exact local source snapshot, matching owner production/integration files and candidate freeze; directory has no Git metadata and no new commit pin is inferred',
  dependencySource: `${own}/uma-ui-baseline/packages/uma-sim-ui/node_modules`,
  loaderSha256: sha(fs.readFileSync(`${output}/harness/tests/compile-ui.mjs`)),
  productionEdits: false, ownerOriginalModified: false,
};
fs.writeFileSync(`${output}/evidence/source-custody.json`, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
fs.copyFileSync('/workspace/scratch/7e7ad6f8e5bd/production/candidate-freeze.json', `${output}/evidence/owner-candidate-freeze.json`);
console.log(JSON.stringify({ main: record.main, tree: record.tree,
  sourceCounts: sourceRows.map(row => ({ name: row.identity, count: row.files.length })),
  ownerFiles: sourceRows[1].files.filter(row => /ComparePanel|branchInput|labStore/.test(row.path)) }, null, 2));
