import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import fs from 'node:fs';
import React from 'react';
import TestRenderer, { act } from 'react-test-renderer';
import { loadUiModule, cleanCompiledUi } from './compile-ui.mjs';

const { ComparePanel } = loadUiModule('components/ComparePanel');
const { useLabStore } = loadUiModule('state/labStore');
const observations = [];
const renderedText = node => typeof node === 'string' ? node : (node.children || []).map(renderedText).join(' ');
after(() => {
  cleanCompiledUi();
  if (process.env.UMA_OVERRIDE_EVIDENCE) fs.writeFileSync(process.env.UMA_OVERRIDE_EVIDENCE,
    JSON.stringify({ source: process.env.UMA_UI_TEST_SOURCE, runtime: process.version, observations }, null, 2) + '\n');
});

async function mount(t) {
  let latest;
  let renderer;
  const requests = [];
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url, init = {}) => {
    const body = init.body === undefined ? null : JSON.parse(init.body);
    requests.push({ url, method: init.method, body });
    let data;
    if (url === '/v1/sessions') data = { sessions: [], active: '' };
    else if (url === '/v1/library') data = { entries: [{ name: 'saved', turn: 0, scenarioId: 'ura' }] };
    else if (url === '/v1/lab/branches') data = { branches: [] };
    else if (url === '/v1/lab/branch') data = { branch: { id: 'fixture-branch', name: body.name }, outcome: {} };
    else throw new Error(`Unexpected fixture request ${init.method} ${url}`);
    return new Response(JSON.stringify(data), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  t.after(async () => {
    if (renderer) await act(async () => renderer.unmount());
    globalThis.fetch = originalFetch;
  });
  function Harness() {
    latest = useLabStore(async () => {});
    return React.createElement(ComparePanel, { lab: latest });
  }
  await act(async () => { renderer = TestRenderer.create(React.createElement(Harness)); });
  await act(async () => { await latest.reloadAll(); });
  const checkpoint = renderer.root.findAllByType('select').find(node =>
    node.findAllByType('option').some(option => option.props.value === 'saved'));
  assert(checkpoint, 'The real component must offer the fixture checkpoint');
  await act(async () => checkpoint.props.onChange({ target: { value: 'saved' } }));
  const button = () => renderer.root.findAllByType('button').find(node => renderedText(node) === 'Run branch');
  return {
    requests,
    input: () => renderer.root.findByType('textarea'),
    button,
    errors: () => renderer.root.findAllByProps({ role: 'alert' }).map(renderedText).join('\n'),
    branchRequests: () => requests.filter(row => row.url === '/v1/lab/branch'),
    change: async value => act(async () => renderer.root.findByType('textarea').props.onChange({ target: { value } })),
    clickIfEnabled: async () => {
      if (!button().props.disabled) await act(async () => button().props.onClick());
    },
  };
}

function observe(name, input, h) {
  const observation = { name, input, displayedInput: h.input().props.value,
    disabled: Boolean(h.button().props.disabled), ariaInvalid: h.input().props['aria-invalid'] ?? null,
    describedBy: h.input().props['aria-describedby'] ?? null, validation: h.errors(), branchRequests: h.branchRequests() };
  observations.push(observation);
  return observation;
}

const malformed = [
  { name: 'mixed malformed line', input: '8:rest\nmalformed\n10:train_stamina', lines: [2] },
  { name: 'missing turn', input: '8:rest\n:rest', lines: [2] },
  { name: 'fractional turn', input: '8.5:rest', lines: [1] },
  { name: 'turn above signed i32 maximum', input: '2147483648:rest', lines: [1] },
  { name: 'turn that would narrow to zero', input: '4294967296:rest', lines: [1] },
  { name: 'empty action', input: '8:  ', lines: [1] },
  { name: 'negative turn', input: '-1:rest', lines: [1] },
  { name: 'nonnumeric turn', input: 'NaN:rest', lines: [1] },
  { name: 'all errors retain original blank-line numbering', input: ' \n8:rest\n\n:rest\n10:\nmalformed', lines: [4, 5, 6] },
];
for (const row of malformed) test(`override form rejects ${row.name} before creating any branch`, async t => {
  const h = await mount(t);
  await h.change(row.input);
  await h.clickIfEnabled();
  const result = observe(t.name, row.input, h);
  assert.equal(result.branchRequests.length, 0, 'The complete authored draft must be refused instead of executing a subset');
  assert.equal(result.displayedInput, row.input, 'Keep the authored text available for correction');
  for (const line of row.lines) assert.match(result.validation, new RegExp(`Line ${line}:`));
  assert.match(result.validation, /turn|action/i, 'Validation should identify how to correct the authored override');
  assert.equal(result.ariaInvalid, true);
  assert(result.describedBy, 'The override field must identify its displayed validation');
});

const valid = [
  { name: 'blank optional overrides', input: ' \n\n\t', expected: [] },
  { name: 'ordinary authored order and whitespace', input: ' 8 : rest \n\n 10:train_stamina ',
    expected: [{ turn: 8, actionId: 'rest' }, { turn: 10, actionId: 'train_stamina' }] },
  { name: 'zero, signed-i32 boundary, action colons and unknown choices', input: '0:rest\n8:race:open\n2147483647:not-yet-known',
    expected: [{ turn: 0, actionId: 'rest' }, { turn: 8, actionId: 'race:open' }, { turn: 2147483647, actionId: 'not-yet-known' }] },
];
for (const row of valid) test(`override form preserves ${row.name}`, async t => {
  const h = await mount(t);
  await h.change(row.input);
  assert.equal(h.button().props.disabled, false, 'A valid draft and selected checkpoint must enable the real control');
  await h.clickIfEnabled();
  const result = observe(t.name, row.input, h);
  assert.equal(result.branchRequests.length, 1);
  assert.deepEqual(result.branchRequests[0].body.overrides, row.expected);
  assert.equal(result.branchRequests[0].body.checkpoint, 'saved');
  assert.equal(result.branchRequests[0].body.maxActions, 120);
  assert.equal(result.branchRequests[0].body.policy, 'bot');
  assert.equal(result.validation, '');
  assert.equal(result.displayedInput, row.input);
});

test('correcting a malformed override enables exactly one complete branch request', async t => {
  const h = await mount(t);
  const invalid = '8:rest\n10:';
  await h.change(invalid);
  await h.clickIfEnabled();
  const before = observe(`${t.name}: before correction`, invalid, h);
  assert.equal(before.branchRequests.length, 0);
  assert.match(before.validation, /Line 2:/);
  const corrected = '8:rest\n10:train_stamina';
  await h.change(corrected);
  assert.equal(h.button().props.disabled, false);
  await h.clickIfEnabled();
  const after = observe(`${t.name}: after correction`, corrected, h);
  assert.equal(after.validation, '');
  assert.equal(after.branchRequests.length, 1);
  assert.deepEqual(after.branchRequests[0].body.overrides,
    [{ turn: 8, actionId: 'rest' }, { turn: 10, actionId: 'train_stamina' }]);
});
