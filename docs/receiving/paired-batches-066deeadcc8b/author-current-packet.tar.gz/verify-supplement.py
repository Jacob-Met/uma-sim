from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
manifest=json.loads((root/"manifest.json").read_text())
def need(ok,why):
 if not ok:raise RuntimeError(why)
for r in manifest["files"]:
 p=root/r["path"];b=p.read_bytes();need(len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"],r["path"])
for name in ["tests","fmt","clippy"]:
 r=json.loads((root/(name+".json")).read_text());need(r["exit"]==0,name);need(hashlib.sha256((root/(name+".log")).read_bytes()).hexdigest()==r["log_sha256"],name+" log")
t=(root/"tests.log").read_text();need("7 passed; 0 failed" in t and "5 passed; 0 failed" in t,"12 focused methods")
closure=json.loads((root/"closure.json").read_text());need(closure["canonical_paths"]==284,"current closure count")
for r in json.loads((root/"current-source.json").read_text())["files"]:
 b=(root/"current"/r["path"]).read_bytes();need(hashlib.sha256(b).hexdigest()==r["sha256"],r["path"]);need(hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==r["git_blob"],r["path"]+" blob")
qualified=json.loads((root/"qualified.json").read_text());need(hashlib.sha256((root/"closure.json").read_bytes()).hexdigest()==qualified["source_closure_sha256"],"build closure")
print(json.dumps({"verified_artifacts":len(manifest["files"]),"canonical_paths":284,"source_overlay":9,"focused_methods":12,"gates_passed":3}))
