from pathlib import Path
import json,hashlib,subprocess,os,time,statistics,math,difflib
root=Path("/Users/me/uma-paired-066deeadcc8b");src=root/"source";ev=root/"evidence";out=ev/"native-consumer";out.mkdir()
baseline=ev/"baseline-uma-sim";candidate=root/"target/debug/uma-sim"
capsule=json.loads((root/"source-capsule.json").read_text());freeze=json.loads((root/"candidate-freeze.json").read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={"baseline":digest(baseline),"candidate":digest(candidate),"overlay":{r["path"]:digest(src/r["path"]) for r in freeze["overlay"]},"canonical":{r["path"]:digest(src/r["path"]) for r in capsule["files"] if r["path"] not in {x["path"] for x in freeze["overlay"]}}}
env=os.environ.copy();env.update({"UMA_REPO_ROOT":str(src),"UMA_RACE_MODEL":"physics"});env.pop("UMA_POLICY_CMD",None)
(out/".uma-sim").mkdir();(out/".uma-sim/session.json").write_bytes(b"authored session sentinel\n")
session=digest(out/".uma-sim/session.json")
processes=[]
def run(name,binary,args):
 command=[str(binary)]+args;t=time.time();p=subprocess.run(command,cwd=out,env=env,capture_output=True,timeout=60)
 (out/(name+".stdout")).write_bytes(p.stdout);(out/(name+".stderr")).write_bytes(p.stderr)
 r={"name":name,"command":command,"cwd":str(out),"environment_overrides":{"UMA_REPO_ROOT":str(src),"UMA_RACE_MODEL":"physics","UMA_POLICY_CMD":"removed"},"exit":p.returncode,"elapsed_seconds":time.time()-t,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest(),"binary_sha256":digest(binary)}
 processes.append(r);(out/(name+".json")).write_text(json.dumps(r,indent=2)+"\n");assert p.returncode==0,(name,p.returncode,p.stderr.decode(errors="replace"));return p.stdout
for name,binary,policy in [("baseline-default",baseline,"default"),("candidate-default",candidate,"default"),("candidate-bot",candidate,"bot")]:
 run(name,binary,["batch","--seeds=42,43,44","--scenario=ura","--trainee=Special Week","--policy="+policy,"--output="+str(out/(name+".jsonl"))])
assert (out/"baseline-default.jsonl").read_bytes()==(out/"candidate-default.jsonl").read_bytes(),"baseline/candidate producer changed"
rows=lambda p:[json.loads(line) for line in p.read_text().splitlines() if line.strip()]
bases=rows(out/"baseline-default.jsonl");inputs=rows(out/"candidate-bot.jsonl")
key=lambda r:(r["scenario"],r["trainee"],r["seed"])
original={key(r):r for r in bases}; assert len(original)==3 and set(original)=={key(r) for r in inputs}
expected=[]
for r in sorted(inputs,key=key):
 b=original[key(r)];expected.append({"scenario":r["scenario"],"trainee":r["trainee"],"seed":r["seed"],"baseline_score":b["score"],"input_score":r["score"],"score_delta":r["score"]-b["score"],"baseline_grade":b["grade"],"input_grade":r["grade"]})
report=json.loads(run("compare-actual",candidate,["compare-batches","--input="+str(out/"candidate-bot.jsonl"),"--baseline="+str(out/"baseline-default.jsonl"),"--format=json"]))
assert report["comparisons"]==expected
d=[r["score_delta"] for r in expected];s=report["summary"];oracle={"count":3,"wins":sum(x>0 for x in d),"ties":sum(x==0 for x in d),"losses":sum(x<0 for x in d),"mean_score_delta":statistics.mean(d),"median_score_delta":statistics.median(d),"min_score_delta":min(d),"max_score_delta":max(d),"population_stddev_score_delta":statistics.pstdev(d)}
for k,v in oracle.items():assert math.isclose(s[k],v,rel_tol=1e-12,abs_tol=1e-12),(k,s[k],v)
aggregate_args=["analyze","--input="+str(out/"candidate-bot.jsonl"),"--compare="+str(out/"baseline-default.jsonl"),"--format=json"]
old_aggregate=run("baseline-aggregate",baseline,aggregate_args);new_aggregate=run("candidate-aggregate",candidate,aggregate_args);assert old_aggregate==new_aggregate,"existing analyze changed"
assert digest(out/".uma-sim/session.json")==session
after={"baseline":digest(baseline),"candidate":digest(candidate),"overlay":{r["path"]:digest(src/r["path"]) for r in freeze["overlay"]},"canonical":{r["path"]:digest(src/r["path"]) for r in capsule["files"] if r["path"] not in {x["path"] for x in freeze["overlay"]}}}
assert before==after
canonical_cli=(ev/"canonical/uma-sim-core/src/bin/uma-sim.rs").read_text();current_cli=(src/"uma-sim-core/src/bin/uma-sim.rs").read_text()
hooks=['#[path = "uma_sim/paired_batches.rs"]\nmod paired_batches;\n\n','        "compare-batches" => std::process::exit(paired_batches::run(&args[1..])),\n','  compare-batches --input=FILE --baseline=FILE [--format=text|json]\n']
recovered=current_cli
for hook in hooks:assert recovered.count(hook)==1;recovered=recovered.replace(hook,"",1)
assert recovered==canonical_cli
canonical_lib=(ev/"canonical/uma-sim-core/src/lib.rs").read_text();current_lib=(src/"uma-sim-core/src/lib.rs").read_text();assert current_lib.replace("pub mod batch_pairs;\n","",1)==canonical_lib
(out/"source.diff").write_text("".join(difflib.unified_diff(canonical_cli.splitlines(True),current_cli.splitlines(True),fromfile="canonical/uma-sim.rs",tofile="candidate/uma-sim.rs"))+"".join(difflib.unified_diff(canonical_lib.splitlines(True),current_lib.splitlines(True),fromfile="canonical/lib.rs",tofile="candidate/lib.rs")))
receipt={"base":capsule["base"],"source_freeze_sha256":digest(root/"candidate-freeze.json"),"process_count":len(processes),"processes":processes,"before":before,"after":after,"producer_bytes_equal":True,"aggregate_bytes_equal":True,"primary_inputs_unchanged":{p.name:digest(p) for p in out.glob("*.jsonl")},"session_sha256":session,"actual_career_pairs":expected,"independent_arithmetic_oracle":oracle,"canonical_cli_recovered_after_three_hooks":True,"canonical_library_recovered_after_one_export":True,"statement":"Actual native maintained-producer outcomes, descriptive comparison only; no performance/statistical claim."}
(out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps({"processes":len(processes),"pairs":expected,"summary":oracle,"receipt_sha256":digest(out/"receipt.json"),"all_source_and_session_bytes_stable":True}))
