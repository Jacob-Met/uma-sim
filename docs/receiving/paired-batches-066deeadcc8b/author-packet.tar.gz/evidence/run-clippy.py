from pathlib import Path
import os,subprocess,time,json,hashlib
root=Path("/Users/me/uma-paired-066deeadcc8b");src=root/"source";ev=root/"evidence";env=os.environ.copy();env.update({"CARGO_TARGET_DIR":str(root/"target"),"CARGO_BUILD_JOBS":"2","CARGO_PROFILE_DEV_DEBUG":"0","CARGO_INCREMENTAL":"0"})
command=["cargo","clippy","--workspace","--all-targets","--offline","--locked"];t=time.time()
with (ev/"candidate-clippy.log").open("wb") as log:p=subprocess.run(command,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
r={"command":command,"cwd":str(src),"exit":p.returncode,"elapsed_seconds":time.time()-t,"source_freeze_sha256":hashlib.sha256((root/"candidate-freeze.json").read_bytes()).hexdigest(),"log_sha256":hashlib.sha256((ev/"candidate-clippy.log").read_bytes()).hexdigest()};(ev/"candidate-clippy.json").write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r))
