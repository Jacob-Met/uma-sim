#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,math,statistics
root=Path(__file__).resolve().parent
manifest=json.loads((root/"packet-manifest.json").read_text())
listed=set()
for row in manifest["files"]:
    rel=Path(row["path"])
    assert not rel.is_absolute() and ".." not in rel.parts
    p=root/rel
    assert p.is_file() and not p.is_symlink(),str(rel)
    data=p.read_bytes()
    assert len(data)==row["bytes"] and hashlib.sha256(data).hexdigest()==row["sha256"],str(rel)
    listed.add(str(rel))
actual={str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p.name!="packet-manifest.json"}
assert actual==listed,sorted(actual^listed)
freeze=json.loads((root/"candidate-freeze.json").read_text())
for row in freeze["overlay"]:
    data=(root/"source"/row["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest()==row["sha256"],row["path"]
    assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==row["git_blob"]
assert len(freeze["overlay"])==9
failed=json.loads((root/"evidence/candidate-attempt-1/candidate-tests.json").read_text())
assert failed["exit"]==101
failure=(root/"evidence/candidate-attempt-1/candidate-tests.log").read_text()
assert "left: Some(0)" in failure and "right: Some(1)" in failure
for name in ["baseline-build","candidate-tests","candidate-format","candidate-clippy"]:
    gate=json.loads((root/"evidence"/(name+".json")).read_text())
    assert gate["exit"]==0,name
    assert hashlib.sha256((root/"evidence"/(name+".log")).read_bytes()).hexdigest()==gate["log_sha256"],name
tests=(root/"evidence/candidate-tests.log").read_text()
assert "7 passed; 0 failed" in tests and "5 passed; 0 failed" in tests
receipt=json.loads((root/"evidence/native-consumer/receipt.json").read_text())
assert receipt["process_count"]==6 and all(p["exit"]==0 for p in receipt["processes"])
assert receipt["before"]==receipt["after"]
assert receipt["producer_bytes_equal"] and receipt["aggregate_bytes_equal"]
assert receipt["canonical_cli_recovered_after_three_hooks"] and receipt["canonical_library_recovered_after_one_export"]
base=root/"evidence/native-consumer"
for p in receipt["processes"]:
    for channel in ["stdout","stderr"]:
        assert hashlib.sha256((base/(p["name"]+"."+channel)).read_bytes()).hexdigest()==p[channel+"_sha256"]
report=json.loads((base/"compare-actual.stdout").read_bytes())
originals=[json.loads(line) for line in (base/"baseline-default.jsonl").read_text().splitlines() if line.strip()]
inputs=[json.loads(line) for line in (base/"candidate-bot.jsonl").read_text().splitlines() if line.strip()]
key=lambda r:(r["scenario"],r["trainee"],r["seed"])
by={key(r):r for r in originals}
assert len(by)==3 and set(by)=={key(r) for r in inputs}
deltas=[]
for actual,r in zip(report["comparisons"],sorted(inputs,key=key)):
    b=by[key(r)];d=r["score"]-b["score"];deltas.append(d)
    assert actual=={"scenario":r["scenario"],"trainee":r["trainee"],"seed":r["seed"],"baseline_score":b["score"],"input_score":r["score"],"score_delta":d,"baseline_grade":b["grade"],"input_grade":r["grade"]}
assert len(report["comparisons"])==3
s=report["summary"]
for name,value in {"count":3,"wins":sum(d>0 for d in deltas),"ties":sum(d==0 for d in deltas),"losses":sum(d<0 for d in deltas),"mean_score_delta":statistics.mean(deltas),"median_score_delta":statistics.median(deltas),"min_score_delta":min(deltas),"max_score_delta":max(deltas),"population_stddev_score_delta":statistics.pstdev(deltas)}.items():
    assert math.isclose(s[name],value,rel_tol=1e-12,abs_tol=1e-12),(name,s[name],value)
print(json.dumps({"verified_artifacts":len(listed),"source_files":9,"final_targeted_methods":12,"captured_native_consumer_processes":6,"preserved_actual_output_failure":True,"arithmetic_recomputed":True}))
