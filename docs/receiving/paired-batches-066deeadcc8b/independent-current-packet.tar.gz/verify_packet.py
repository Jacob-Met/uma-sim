from pathlib import Path
import hashlib,json,runpy
r=Path(__file__).resolve().parent
def need(c,m):
 if not c:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((r/"manifest.json").read_text())
for x in manifest["files"]:
 b=(r/x["path"]).read_bytes();need(len(b)==x["bytes"] and sha(b)==x["sha256"],x["path"])
need(sha((r/"receive_paired.py").read_bytes())=="8b875808a6c3c6341937102edb1ce44d9d67b15647494d52724999ea9b6128d5","receiver")
m=runpy.run_path(str(r/"receive_paired.py"))
for fmt in ("json","text"):
 d=r/"cases"/("maintained_native_batch_"+fmt);w=d/"work"
 b=[json.loads(x) for x in (w/"baseline data.jsonl").read_bytes().splitlines()]
 i=[json.loads(x) for x in (w/"input Ω data.jsonl").read_bytes().splitlines()]
 expected=m["oracle"](b,i);out=(d/"stdout.bin").read_bytes()
 record=json.loads((d/"process.json").read_text())
 need(record["exit"]==0 and record["stdout_sha256"]==sha(out),"process")
 if fmt=="json":m["check_json"](json.loads(out),expected)
 else:m["check_text"](out.decode(),expected)
 need(json.loads((d/"before.json").read_text())==json.loads((d/"after.json").read_text())==m["snapshots"](w),"custody")
need((r/"aggregate.stdout").read_bytes()==(r/"baseline-aggregate.stdout").read_bytes(),"aggregate bytes")
need(json.loads((r/"aggregate-process.json").read_text())["exit"]==0,"aggregate status")
need(json.loads((r/"aggregate-before.json").read_text())==json.loads((r/"aggregate-after.json").read_text())==m["snapshots"](r/"aggregate-work"),"aggregate custody")
receipt=json.loads((r/"receiving-receipt.json").read_text())
need(receipt["new_actual_processes"]==3 and receipt["unchanged_owned_source_leaves"]==9 and receipt["physical_canonical_paths"]==284,"source totals")
print(json.dumps({"verified_artifacts":len(manifest["files"]),"new_actual_processes":3,"paired_cases":2,"aggregate_cases":1,"canonical_paths":284,"original_owned_overlay":9},sort_keys=True))
