from pathlib import Path
import hashlib,json
root=Path('/Users/me/uma-paired-066deeadcc8b-root-review')
canonical=json.loads((root/'canonical-baseline.json').read_text())
tree={x['path']:x for x in canonical['tree']['tree'] if x['type']!='tree'}
freeze=json.loads((root/'author-candidate-freeze.json').read_text())
src=Path(freeze['source_root'])
cli=(src/'uma-sim-core/src/bin/uma-sim.rs').read_text()
hooks=['\n#[path = "uma_sim/paired_batches.rs"]\nmod paired_batches;\n',
       '        "compare-batches" => std::process::exit(paired_batches::run(&args[1..])),\n',
       '  compare-batches --input=FILE --baseline=FILE [--format=text|json]\n']
for h in hooks:
 if cli.count(h)!=1: raise RuntimeError('unexpected CLI hook')
 cli=cli.replace(h,'',1)
original=next(x['content'] for x in canonical['inspected_baseline'] if x['path']=='uma-sim-core/src/bin/uma-sim.rs')
if cli!=original:raise RuntimeError('CLI reconstruction mismatch')
lib=(src/'uma-sim-core/src/lib.rs').read_text()
if lib.count('pub mod batch_pairs;\n')!=1:raise RuntimeError('library export count')
lib=lib.replace('pub mod batch_pairs;\n','',1)
if lib!=(root/'canonical-lib.rs').read_text():raise RuntimeError('library reconstruction mismatch')
supplement=json.loads((root/'canonical-examples-supplement.json').read_text())
for x in supplement['files']:
 b=(src/x['path']).read_bytes();entry=tree[x['path']]
 if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256'] or hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()!=x['git_blob'] or entry['sha']!=x['git_blob'] or entry['mode']!=x['mode']:
  raise RuntimeError('example mismatch '+x['path'])
for x in freeze['overlay']:
 if hashlib.sha256((src/x['path']).read_bytes()).hexdigest()!=x['sha256']:raise RuntimeError('candidate changed '+x['path'])
r={'cli_three_additive_hooks_removed_byte_exact':True,'library_one_export_removed_byte_exact':True,
   'unchanged_canonical_physical_leaves':271,'canonical_declared_examples_verified':len(supplement['files']),
   'overlay_leaves_still_exact':len(freeze['overlay']),'production_review':'No blocker: private validated batch constructor preserves nonempty unique cohorts; bounded reader precedes parse; exact key sets precede numeric calculation; i64 casts precede subtraction; i64 sum bounded by admission; deterministic per-pair and text ordering; all preparation precedes output; Unix delivery and best-effort diagnostics exercised.'}
f=root/'final-source-review.json';f.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'review':r,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}))
