#!/usr/bin/env python3
"""Independent executable receiving for uma-sim compare-batches.

Written from the canonical 7a2e15f6 CLI/aggregate source and the stated new
consumer contract, before candidate source or tests are inspected.
Only Python standard library is used. All reports are authored fixtures.
"""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone

BASE_COMMIT = "7a2e15f623a559b2d9d425e4e7b68c1e71f24cbb"
BASE_TREE = "895e790957919ee1d9e64f6336c0fc176bfb35cb"
LIMIT_BYTES = 16 * 1024 * 1024
LIMIT_ROWS = 100000

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def row(seed=1, score=100, scenario="ura", trainee="Special Week", grade="F", **extra):
    return dict(seed=seed, score=score, scenario=scenario, trainee=trainee, grade=grade, **extra)

def jsonl(rows):
    return ("\n".join(json.dumps(x, ensure_ascii=False, separators=(",", ":")) for x in rows) + "\n").encode("utf-8")

def key(r):
    return (r["scenario"], r["trainee"], r["seed"])

def oracle(baseline, incoming):
    old = {key(x): x for x in baseline}
    require(len(old) == len(baseline), "oracle baseline duplicates")
    new = {key(x): x for x in incoming}
    require(len(new) == len(incoming) and old.keys() == new.keys(), "oracle cohort")
    comparisons = []
    for k in sorted(old):
        b, i = old[k], new[k]
        comparisons.append(dict(scenario=k[0], trainee=k[1], seed=k[2],
                                baseline_score=b["score"], input_score=i["score"],
                                score_delta=i["score"] - b["score"],
                                baseline_grade=b["grade"], input_grade=i["grade"]))
    deltas = [x["score_delta"] for x in comparisons]
    mean = sum(deltas) / len(deltas)
    summary = dict(count=len(deltas), wins=sum(d > 0 for d in deltas),
                   ties=deltas.count(0), losses=sum(d < 0 for d in deltas),
                   mean_score_delta=mean, median_score_delta=statistics.median(deltas),
                   min_score_delta=min(deltas), max_score_delta=max(deltas),
                   population_stddev_score_delta=math.sqrt(sum((d-mean)**2 for d in deltas)/len(deltas)))
    return dict(format="uma-sim.paired-batches.v1", direction="input_minus_baseline",
                identity_fields=["scenario", "trainee", "seed"], summary=summary, comparisons=comparisons)

def check_json(actual, expected):
    for k in ["format", "direction", "identity_fields"]:
        require(actual[k] == expected[k], "JSON " + k)
    require(actual["comparisons"] == expected["comparisons"], "literal sorted pair identities/scores/grades/deltas")
    for k, v in expected["summary"].items():
        got = actual["summary"][k]
        if k in ["mean_score_delta", "median_score_delta", "population_stddev_score_delta"]:
            require(isinstance(got, (float, int)) and not isinstance(got, bool) and math.isfinite(got), "finite " + k)
            require(math.isclose(got, v, rel_tol=2e-13, abs_tol=1e-9), "arithmetic " + k)
        else:
            require(type(got) is int and got == v, "integer " + k)

def check_text(text, expected):
    lines = text.splitlines()
    s = expected["summary"]
    require(text.endswith("\n"), "newline-terminated text")
    require(lines[0] == "Paired batch comparison (input minus baseline)", "text title")
    require(lines[1] == f"Pairs: {s['count']}; wins: {s['wins']}; ties: {s['ties']}; losses: {s['losses']}", "text counts")
    m = re.fullmatch(r"Score delta: mean (-?\d+\.\d{6}); median (-?\d+\.\d{6}); min (-?\d+); max (-?\d+); population stddev (\d+\.\d{6})", lines[2])
    require(m is not None, "text six-decimal summary syntax")
    vals = [float(m[1]), float(m[2]), int(m[3]), int(m[4]), float(m[5])]
    keys = ["mean_score_delta", "median_score_delta", "min_score_delta", "max_score_delta", "population_stddev_score_delta"]
    for k, got in zip(keys, vals):
        require(math.isclose(got, s[k], rel_tol=2e-13, abs_tol=0.500001e-6), "text " + k)
    require(lines[3] == "Largest absolute score changes (up to 10; ties by scenario, trainee, seed):", "text top explanation")
    require(lines[4] == "delta\tbaseline\tinput\t[scenario,trainee,seed]", "text columns")
    top = sorted(expected["comparisons"], key=lambda x: (-abs(x["score_delta"]), key(x)))[:10]
    require(len(lines) == 5 + len(top), "at most ten text pairs")
    for line, pair in zip(lines[5:], top):
        cols = line.split("\t")
        require(len(cols) == 4, "one-line literal text fields")
        require(cols[:3] == [f"{pair['score_delta']:+d}", str(pair["baseline_score"]), str(pair["input_score"])], "text literal score columns")
        require(json.loads(cols[3]) == list(key(pair)), "text literal identity array")

def regular_cases():
    cases = []
    base = [row(1, 100), row(2, 110), row(3, 120)]
    incoming = [row(3, 100, grade="new3"), row(1, 110, grade="new1"), row(2, 120, grade="new2")]
    def good(name, b=base, i=incoming, **kw):
        cases.append(dict(name=name, baseline=b, incoming=i, expect="json", **kw))
    def bad(name, b=base, i=incoming, **kw):
        cases.append(dict(name=name, baseline=b, incoming=i, expect="error", **kw))
    good("shuffled_pairing_differs_from_aggregate_median")
    good("input_order_reversed", i=list(reversed(incoming)))
    good("baseline_order_reversed", b=list(reversed(base)))
    good("same_file_ties", i=base, same_file=True)
    good("negative_direction", b=incoming, i=base)
    good("single_pair_population_zero", b=[row(-7, -20)], i=[row(-7, 80)])
    good("even_median_population", b=[row(n, 0) for n in range(4)],
         i=[row(n, s) for n, s in enumerate([-8, 4, 1, 3])])
    extremes = [-2**63, -1, 0, 2**63-1]
    good("signed_seed_and_score_endpoints", b=[row(n, -2**31 if z%2==0 else 2**31-1) for z,n in enumerate(extremes)],
         i=[row(n, 2**31-1 if z%2==0 else -2**31) for z,n in reversed(list(enumerate(extremes)))])
    identities = [("ura", "Alpha", -1), ("ura", "Beta", -1), ("unity", "Alpha", -1), ("e\u0301", "A", 2), ("é", "A", 2), ("😀", "A", 2)]
    b = [row(k[2], z, k[0], k[1]) for z,k in enumerate(identities)]
    i = [dict(x, score=x["score"] + z - 2) for z,x in enumerate(b)]
    good("exact_identity_dimensions_and_unicode", b=b, i=list(reversed(i)))
    good("literal_whitespace_and_controls", b=[row(-3, 20, " \t", "line\n\u0000<script>", " \t")],
         i=[row(-3, 22, " \t", "line\n\u0000<script>", " Ω")])
    good("utf8_metadata_exact_byte_limits", b=[row(1, 1, "é"*128, "Ω"*128, "🎮"*16)],
         i=[row(1, 2, "é"*128, "Ω"*128, "🎮"*16)])
    good("unused_terminal_fields_ignored", b=[row(1, 5, stats={"not": "validated"}, u="ignored", score_before_shop=None, policy="baseline")],
         i=[row(1, 6, stats=False, u={"unknown": [1,2]}, score_before_shop=["ignored"], policy="input")])
    good("blank_crlf_and_missing_final_newline", input_bytes=b"\r\n \t\r\n"+jsonl(incoming).rstrip(b"\n").replace(b"\n",b"\r\n"), baseline_bytes=b"\n"+jsonl(base)+b" \t\n")
    good("relative_paths_spaces_unicode", relative_paths=True)
    top_base = [row(n, 100, "s"+str(n%3), "T"+str(n%2)) for n in range(15)]
    ds = [7,-7,0,21,-21,5,-5,9,-9,21,-21,2,3,-3,1]
    top_input = [dict(x, score=x["score"]+ds[z]) for z,x in enumerate(top_base)]
    cases.append(dict(name="text_top_ten_absolute_delta_and_identity_ties", baseline=top_base, incoming=list(reversed(top_input)), expect="text"))
    cases.append(dict(name="default_text_literal_controls", baseline=[row(-3,20," \t","line\n\u0000<script>"," \t")],
                      incoming=[row(-3,22," \t","line\n\u0000<script>"," Ω")], expect="text", omit_format=True))
    for field in ["seed", "scenario", "trainee", "grade", "score"]:
        rs=copy.deepcopy(incoming);rs[-1].pop(field);bad("missing_"+field, i=rs)
    for field, values in {
        "seed":[True,1.0,"1",None,2**63,-2**63-1],
        "score":[True,1.0,"100",None,2**31,-2**31-1],
        "scenario":["",None,True,"é"*128+"x"],
        "trainee":["",None,3,"Ω"*128+"x"],
        "grade":["",None,{}, "🎮"*16+"x"]
    }.items():
        for z,value in enumerate(values):
            rs=copy.deepcopy(incoming);rs[-1][field]=value;bad(f"invalid_{field}_{z}",i=rs)
    for name, payload in [("malformed_late_json",jsonl(incoming)+b"{bad}\n"),
                          ("valid_json_then_trailing_garbage",jsonl(incoming)+b"{}junk\n"),
                          ("non_object_row",jsonl(incoming)+b"[]\n"),
                          ("null_row",jsonl(incoming)+b"null\n"),
                          ("invalid_utf8",jsonl(incoming)+b"\xff\n"),
                          ("empty_input",b""),
                          ("blank_only_input",b"\n \t\r\n")]:
        bad(name,input_bytes=payload)
    bad("empty_baseline",baseline_bytes=b"")
    bad("late_baseline_malformed",baseline_bytes=jsonl(base)+b"{bad}\n")
    bad("duplicate_input_same_record",i=incoming+[incoming[0]])
    bad("duplicate_input_conflicting_score",i=incoming+[dict(incoming[0],score=500)])
    bad("duplicate_baseline",b=base+[base[0]])
    bad("missing_input_partner",i=incoming[:-1])
    bad("extra_input_partner",i=incoming+[row(500,0)])
    for field,value in [("seed",500),("scenario","other"),("trainee","other")]:
        rs=copy.deepcopy(incoming);rs[-1][field]=value;bad("unmatched_"+field,i=rs)
    bad("unicode_normalization_not_identity",b=[row(1,0,"é")],i=[row(1,0,"e\u0301")])
    bad("missing_input_file",missing_input=True)
    bad("directory_input",directory_input=True)
    bad("missing_baseline_file",missing_baseline=True)
    for name, flags in [
        ("missing_all_flags",[]),("missing_input_flag",["--baseline={baseline}"]),
        ("missing_baseline_flag",["--input={input}"]),("empty_input_flag",["--input=","--baseline={baseline}"]),
        ("empty_baseline_flag",["--input={input}","--baseline="]),
        ("empty_format",["--input={input}","--baseline={baseline}","--format="]),
        ("unknown_format",["--input={input}","--baseline={baseline}","--format=csv"]),
        ("duplicate_input_flag",["--input={input}","--input={input}","--baseline={baseline}"]),
        ("duplicate_baseline_flag",["--input={input}","--baseline={baseline}","--baseline={baseline}"]),
        ("duplicate_format_flag",["--input={input}","--baseline={baseline}","--format=json","--format=json"]),
        ("unknown_flag",["--input={input}","--baseline={baseline}","--seed=7"]),
        ("unexpected_positional",["--input={input}","--baseline={baseline}","extra"]),
        ("help_is_sole_argument",["--help","--input={input}","--baseline={baseline}"])
    ]:
        bad(name,flags=flags)
    cases.append(dict(name="sole_help",baseline=base,incoming=incoming,expect="help",flags=["--help"]))
    for name, pipe in [("unwritable_stdout_short","readonly"),("broken_stdout_pipe","broken")]:
        bad(name,b=[row()],i=[row(score=101)],output_sink=pipe,output_error=True)
    bad("unwritable_stdout_large",b=top_base*0+[row(n,100) for n in range(80)],
        i=[row(n,101) for n in range(80)],output_sink="readonly",output_error=True)
    bad("unwritable_stderr_still_exit_one",missing_input=True,diagnostic_sink="readonly")
    return cases

def limit_cases():
    minimal = row(1,0,"s","t","g")
    prefix=json.dumps(dict(minimal,ignored=""),separators=(",",":")).encode()
    exact = prefix[:-2] + b"x"*(LIMIT_BYTES-len(prefix)-1) + b'"}\n'
    require(len(exact)==LIMIT_BYTES, "16 MiB exact fixture")
    b=[row(n,0,"s","t","g") for n in range(LIMIT_ROWS)]
    many=jsonl(b)
    return [
        dict(name="exact_16mib_input",baseline=[minimal],incoming=[minimal],input_bytes=exact,expect="json"),
        dict(name="over_16mib_input",baseline=[minimal],incoming=[minimal],input_bytes=exact+b" ",expect="error"),
        dict(name="over_16mib_baseline",baseline=[minimal],incoming=[minimal],baseline_bytes=exact+b" ",expect="error"),
        dict(name="exact_100000_records",baseline=b,incoming=list(reversed(b)),expect="json"),
        dict(name="over_100000_input_records",baseline=b,incoming=b+[row(LIMIT_ROWS,0,"s","t","g")],expect="error"),
        dict(name="over_100000_baseline_records",baseline=b+[row(LIMIT_ROWS,0,"s","t","g")],incoming=b,expect="error")
    ]

def snapshots(root):
    result={}
    for p in sorted(root.rglob("*")):
        if p.is_symlink():
            result[p.relative_to(root).as_posix()]={"symlink":os.readlink(p)}
        elif p.is_file():
            b=p.read_bytes();result[p.relative_to(root).as_posix()]={"bytes":len(b),"sha256":sha(b)}
        elif p.is_dir():
            result[p.relative_to(root).as_posix()]={"directory":True}
    return result

def run_case(binary, root, case):
    d=root/case["name"];d.mkdir()
    work=d/"work";work.mkdir()
    session=work/".uma-sim";session.mkdir();(session/"session.json").write_bytes(b"opaque-existing-session\x00\n")
    (work/"unrelated-output.csv").write_bytes(b"preserve,this\n1,2\n")
    inp=work/"input Ω data.jsonl";baseline=work/"baseline data.jsonl"
    if not case.get("missing_input"):
        if case.get("directory_input"):inp.mkdir()
        else:inp.write_bytes(case.get("input_bytes",jsonl(case["incoming"])))
    if not case.get("missing_baseline"):baseline.write_bytes(case.get("baseline_bytes",jsonl(case["baseline"])))
    if case.get("same_file"):inp=baseline
    ip=str(inp.relative_to(work)) if case.get("relative_paths") else str(inp)
    bp=str(baseline.relative_to(work)) if case.get("relative_paths") else str(baseline)
    flags=case.get("flags",["--input={input}","--baseline={baseline}"]+([] if case.get("omit_format") else ["--format="+("text" if case["expect"]=="text" else "json")]))
    args=[str(binary),"compare-batches"]+[x.replace("{input}",ip).replace("{baseline}",bp) for x in flags]
    before=snapshots(work)
    write_json(d/"before.json",before)
    env=os.environ.copy();env["UMA_REPO_ROOT"]=str(work/"nonexistent-unrelated-repo")
    stdout=subprocess.PIPE;stderr=subprocess.PIPE;handles=[];fd=None
    if case.get("output_sink")=="readonly":
        h=open(os.devnull,"rb");handles.append(h);stdout=h
    elif case.get("output_sink")=="broken":
        rd,wr=os.pipe();os.close(rd);fd=wr;stdout=wr
    if case.get("diagnostic_sink")=="readonly":
        h=open(os.devnull,"rb");handles.append(h);stderr=h
    start=time.monotonic()
    try:
        result=subprocess.run(args,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=60)
        out=result.stdout or b"";err=result.stderr or b""
        code=result.returncode
    finally:
        for h in handles:h.close()
        if fd is not None:os.close(fd)
    duration=time.monotonic()-start
    (d/"stdout.bin").write_bytes(out);(d/"stderr.bin").write_bytes(err)
    after=snapshots(work);write_json(d/"after.json",after)
    observation=dict(name=case["name"],argv=args,exit=code,seconds=duration,stdout_bytes=len(out),stdout_sha256=sha(out),
                     stderr_bytes=len(err),stderr_sha256=sha(err),output_sink=case.get("output_sink","pipe"),
                     diagnostic_sink=case.get("diagnostic_sink","pipe"),before_equals_after=before==after)
    write_json(d/"process.json",observation)
    try:
        require(before==after,"input/session/unrelated filesystem custody")
        if case["expect"]=="error":
            require(code==1,"refusal exits exactly one")
            require(out==b"","refusal has no primary output")
            if not case.get("diagnostic_sink"):require(bool(err.strip()),"best-effort diagnostic")
        elif case["expect"]=="help":
            require(code==0,"help success")
            text=out.decode("utf-8")
            require("compare-batches" in text and "--input" in text and "--baseline" in text,"help command contract")
        else:
            require(code==0,"positive exits zero")
            expected=oracle(case["baseline"],case["incoming"])
            if case["expect"]=="json":
                actual=json.loads(out.decode("utf-8"))
                check_json(actual,expected)
                if len(expected["comparisons"])<=100:
                    write_json(d/"oracle.json",expected)
                if case["name"]=="shuffled_pairing_differs_from_aggregate_median":
                    require(actual["summary"]["median_score_delta"]==10,"paired median differs from aggregate median delta zero")
            else:
                check_text(out.decode("utf-8"),expected)
        observation["accepted"]=True
    except Exception as e:
        observation["accepted"]=False;observation["failure"]=repr(e)
    write_json(d/"case-result.json",observation)
    return observation

def receiver_self_controls():
    expected=oracle([row(1,0),row(2,10),row(3,20)],[row(3,0),row(1,10),row(2,20)])
    check_json(expected,expected)
    for change in ["delta_sign","seed_rounding","wrong_mean","pair_order"]:
        bad=copy.deepcopy(expected)
        if change=="delta_sign":bad["comparisons"][0]["score_delta"]*=-1
        elif change=="seed_rounding":bad["comparisons"][0]["seed"]=9007199254740992
        elif change=="wrong_mean":bad["summary"]["mean_score_delta"]+=1
        else:bad["comparisons"].reverse()
        caught=False
        try:check_json(bad,expected)
        except AssertionError:caught=True
        require(caught,"receiver rejects "+change)
    return {"accepted_golden":True,"deliberate_report_defects_rejected":4}

def main():
    p=argparse.ArgumentParser();p.add_argument("--binary",type=Path,required=True);p.add_argument("--out",type=Path,required=True)
    p.add_argument("--suite",choices=["regular","limits","baseline"],default="regular");p.add_argument("--only",default="")
    a=p.parse_args();binary=a.binary.resolve();require(binary.is_file(),"binary exists")
    require(not a.out.exists(),"fresh evidence directory");a.out.mkdir(parents=True)
    freeze=dict(receiver_sha256=sha(Path(__file__).read_bytes()),binary=str(binary),binary_sha256=sha(binary.read_bytes()),
                receiving_base_commit=BASE_COMMIT,receiving_base_tree=BASE_TREE,started_at=datetime.now(timezone.utc).isoformat(),
                python=sys.version,platform=sys.platform,suite=a.suite,receiver_self_controls=receiver_self_controls())
    write_json(a.out/"execution-source.json",freeze)
    if a.suite=="baseline":
        work=a.out/"work";work.mkdir();(work/".uma-sim").mkdir();(work/".uma-sim/session.json").write_bytes(b"existing-session\n")
        b=[row(1,0),row(2,10),row(3,20)];i=[row(3,0),row(1,10),row(2,20)]
        (work/"base.jsonl").write_bytes(jsonl(b));(work/"new.jsonl").write_bytes(jsonl(i));before=snapshots(work)
        commands=[
            ["compare-batches","--input=new.jsonl","--baseline=base.jsonl","--format=json"],
            ["analyze","--input=new.jsonl","--compare=base.jsonl","--format=json"]
        ]
        records=[]
        for n,args in enumerate(commands):
            result=subprocess.run([str(binary)]+args,cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
            (a.out/f"baseline-{n}.stdout").write_bytes(result.stdout);(a.out/f"baseline-{n}.stderr").write_bytes(result.stderr)
            records.append(dict(argv=[str(binary)]+args,exit=result.returncode,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
        out=json.loads((a.out/"baseline-1.stdout").read_text())
        require(out["comparison"]["score_mean_delta"]==0 and out["comparison"]["score_median_delta"]==0,"existing aggregate witness")
        require(b"uma-sim.paired-batches.v1" not in (a.out/"baseline-0.stdout").read_bytes(),"paired command not implemented")
        require(before==snapshots(work),"baseline custody")
        receipt=dict(source=freeze,baseline_command_absence=True,existing_aggregate_median_delta=0,independent_paired_median_delta=10,
                     actual_processes=2,processes=records,files_preserved=True)
        write_json(a.out/"receipt.json",receipt);print(json.dumps(receipt));return
    cases=regular_cases() if a.suite=="regular" else limit_cases()
    if a.only:
        chosen=set(a.only.split(","));cases=[c for c in cases if c["name"] in chosen]
        require(len(cases)==len(chosen),"all selected names exist")
    results=[]
    for case in cases:
        try:record=run_case(binary,a.out,case)
        except Exception as e:
            record={"name":case["name"],"accepted":False,"execution_failure":repr(e)}
            write_json(a.out/(case["name"]+".execution-failure.json"),record)
        results.append(record)
        print(json.dumps({k:record[k] for k in ["name","accepted","failure","execution_failure"] if k in record}),flush=True)
    receipt=dict(source=freeze,distinct_cases=len(results),accepted=sum(x["accepted"] for x in results),results=results)
    write_json(a.out/"receipt.json",receipt)
    require(receipt["accepted"]==receipt["distinct_cases"],"one or more receiving cases failed")

if __name__=="__main__":
    main()
