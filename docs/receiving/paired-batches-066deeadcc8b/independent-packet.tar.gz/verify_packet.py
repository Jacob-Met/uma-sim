#!/usr/bin/env python3
"""Recompute immutable saved receiving; does not execute a simulator binary."""
from pathlib import Path
import hashlib,json,math,runpy
ROOT=Path(__file__).resolve().parent
def need(condition,message):
    if not condition: raise RuntimeError(message)
def digest(data): return hashlib.sha256(data).hexdigest()
manifest=json.loads((ROOT/"manifest.json").read_text())
for item in manifest["files"]:
    p=ROOT/item["path"];data=p.read_bytes()
    need(len(data)==item["bytes"] and digest(data)==item["sha256"],"artifact "+item["path"])
need(digest((ROOT/"receive_paired.py").read_bytes())=="8b875808a6c3c6341937102edb1ce44d9d67b15647494d52724999ea9b6128d5","receiver pin")
need(digest((ROOT/"author-candidate-freeze.json").read_bytes())=="28029900f8ac9131ffe57e09c62212ec8761f93591fc5198802453c1d6ec753a","candidate freeze")
mod=runpy.run_path(str(ROOT/"receive_paired.py"))
need(mod["receiver_self_controls"]()["deliberate_report_defects_rejected"]==4,"negative oracles")
freeze=json.loads((ROOT/"author-candidate-freeze.json").read_text())
for item in freeze["overlay"]:
    b=(ROOT/"source-overlay"/item["path"]).read_bytes()
    need(len(b)==item["bytes"] and digest(b)==item["sha256"],"overlay "+item["path"])
    need(hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==item["git_blob"],"overlay Git blob")
source_review=json.loads((ROOT/"final-source-review.json").read_text())
need(source_review["cli_three_additive_hooks_removed_byte_exact"] and source_review["library_one_export_removed_byte_exact"],"canonical reconstruction")
need(source_review["unchanged_canonical_physical_leaves"]==271 and source_review["canonical_declared_examples_verified"]==9,"source closure")
baseline=json.loads((ROOT/"baseline/receipt.json").read_text())
need(baseline["actual_processes"]==2 and baseline["baseline_command_absence"],"baseline observations")
aggregate=json.loads((ROOT/"baseline/baseline-1.stdout").read_text())
need(aggregate["comparison"]["score_mean_delta"]==0 and aggregate["comparison"]["score_median_delta"]==0,"baseline aggregate")
verified=0
def check_case(folder,case):
    global verified
    d=ROOT/folder/case["name"];record=json.loads((d/"case-result.json").read_text())
    process=json.loads((d/"process.json").read_text())
    out=(d/"stdout.bin").read_bytes();err=(d/"stderr.bin").read_bytes()
    need(record["accepted"] and record["name"]==case["name"],"record acceptance")
    need(record["exit"]==process["exit"],"process status")
    need(len(out)==process["stdout_bytes"] and digest(out)==process["stdout_sha256"],"stdout custody")
    need(len(err)==process["stderr_bytes"] and digest(err)==process["stderr_sha256"],"stderr custody")
    before=json.loads((d/"before.json").read_text());after=json.loads((d/"after.json").read_text())
    need(before==after==mod["snapshots"](d/"work"),"input/session custody "+case["name"])
    if case["expect"]=="error":
        need(process["exit"]==1 and out==b"","negative delivery "+case["name"])
        if not case.get("diagnostic_sink"):need(bool(err.strip()),"diagnostic")
    elif case["expect"]=="help":
        need(process["exit"]==0 and b"compare-batches" in out and b"--baseline" in out,"help")
    else:
        need(process["exit"]==0,"positive delivery")
        expected=mod["oracle"](case["baseline"],case["incoming"])
        if case["expect"]=="json":mod["check_json"](json.loads(out),expected)
        else:mod["check_text"](out.decode("utf-8"),expected)
    verified+=1
for c in mod["regular_cases"]():check_case("candidate-regular",c)
for c in mod["limit_cases"]():check_case("candidate-limits",c)
r=json.loads((ROOT/"candidate-native-producer/receipt.json").read_text())
need(r["accepted"]==2 and r["actual_comparison_processes"]==2 and r["source_producer_processes_attributed_to_author"]==6,"producer attribution")
for fmt in ["json","text"]:
    d=ROOT/"candidate-native-producer"/("maintained_native_batch_"+fmt)/"work"
    b=(d/"baseline data.jsonl").read_bytes();i=(d/"input Ω data.jsonl").read_bytes()
    need(digest(b)==r["source_hashes"]["baseline-default.jsonl"] and digest(i)==r["source_hashes"]["candidate-bot.jsonl"],"original producer bytes")
    case={"name":"maintained_native_batch_"+fmt,"baseline":[json.loads(x) for x in b.splitlines()],
          "incoming":[json.loads(x) for x in i.splitlines()],"expect":fmt}
    check_case("candidate-native-producer",case)
need(verified==92,"candidate case count")
receipt=json.loads((ROOT/"receiving-receipt.json").read_text())
need(receipt["accepted_candidate_cases"]==verified and receipt["actual_candidate_processes"]==92 and receipt["baseline_processes"]==2,"receiving totals")
print(json.dumps({"verified_artifacts":len(manifest["files"]),"candidate_cases":verified,"baseline_processes":2,
                  "source_overlay":9,"unchanged_physical_source_leaves":271,"declared_examples":9,
                  "actual_native_career_pairs":3},sort_keys=True))
