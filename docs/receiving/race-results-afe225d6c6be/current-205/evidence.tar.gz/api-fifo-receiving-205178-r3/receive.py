import os,json,time,hashlib,select,pathlib,traceback
out=pathlib.Path(__file__).parent
fifo=pathlib.Path('/dev/shm/hamon-afe225d6c6be-root-uma205-transfer-r3.fifo')
expected=[('uma-sim-api-205178.gz',1896491,'093a07b6783299d6bc2e515da39b0db62c925f3b89df1584181c821897890fba'),('metadata.tar.gz',118749,'4f392dadd8d9d15469a2e6eb2c43008c4fdab6aadf1f21a6d7b62f7e788ac6b7')]
receipt={'transport':'one bounded shared named FIFO, no network','fifo':str(fifo),'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'timeout_seconds':60,'files':[],'status':'receiving'}
fd=None
try:
 fd=os.open(fifo,os.O_RDONLY|os.O_NONBLOCK)
 deadline=time.monotonic()+60
 for name,size,sha in expected:
  part=out/(name+'.part')
  h=hashlib.sha256(); got=0
  with part.open('xb') as stream:
   while got<size:
    if time.monotonic()>=deadline: raise TimeoutError('bounded FIFO receive reached 60 seconds')
    ready,_,_=select.select([fd],[],[],min(0.2,max(0,deadline-time.monotonic())))
    if not ready: continue
    try: data=os.read(fd,min(65536,size-got))
    except BlockingIOError: continue
    if not data:
     time.sleep(0.03); continue
    stream.write(data);h.update(data);got+=len(data)
  rec={'name':name,'bytes':got,'sha256':h.hexdigest(),'expected_bytes':size,'expected_sha256':sha}
  receipt['files'].append(rec)
  assert got==size and h.hexdigest()==sha,rec
  part.rename(out/name)
 receipt['status']='verified'
except BaseException as exc:
 receipt['status']='failed'
 receipt['error']=repr(exc)
 receipt['traceback']=traceback.format_exc()
finally:
 if fd is not None: os.close(fd)
 receipt['end_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (out/'root-fifo-receiving-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
