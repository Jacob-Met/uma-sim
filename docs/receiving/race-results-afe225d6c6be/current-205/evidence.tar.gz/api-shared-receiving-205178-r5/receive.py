import pathlib,json,hashlib,time,os,traceback,gzip
out=pathlib.Path(__file__).parent
shared=pathlib.Path('/dev/shm/hamon-afe225d6c6be-coordination-uma/native-205178f-r5')
first=out.parent/'api-shared-receiving-205178-r4/part-000.bin'
rows=json.loads((out/'piece-plan.json').read_text())
receipt={'transport':'bounded128KiB shared-file pieces with private exact-byte ACK custody','start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'deadline_seconds':600,'pieces':[],'status':'receiving'}
deadline=time.monotonic()+600
try:
 first_bytes=first.read_bytes()
 assert len(first_bytes)==196608 and hashlib.sha256(first_bytes).hexdigest()=='0be731f6970b29501d35509616a78c9fbf80da5986a0f83b909554bdc378cc0b'
 offset=196608
 for index,expected_offset,size,sha in rows:
  assert offset==expected_offset
  name='part-%03d.bin'%index
  src=shared/name
  while not src.exists() or src.stat().st_size!=size:
   if time.monotonic()>=deadline:raise TimeoutError('bounded shared receive at '+name)
   time.sleep(.2)
  raw=src.read_bytes()
  assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha,name
  dst=out/name
  with dst.open('xb') as f:f.write(raw)
  assert dst.read_bytes()==raw
  ack={'status':'verified','index':index,'offset':offset,'bytes':size,'sha256':sha,'root_private_copy':str(dst)}
  with (out/('root-ack-%03d.json'%index)).open('x') as f:json.dump(ack,f)
  receipt['pieces'].append(ack)
  (out/'progress.json').write_text(json.dumps(receipt,indent=2)+'\n')
  while True:
   v=os.statvfs(shared)
   if v.f_bavail*v.f_frsize>=131072+8192:break
   if time.monotonic()>=deadline:raise TimeoutError('bounded positive ACK-capacity wait at '+name)
   time.sleep(.2)
  target=shared/('root-ack-%03d.json'%index)
  temp=shared/('root-ack-%03d.json.ready-part'%index)
  assert not target.exists() and not temp.exists()
  with temp.open('x') as f:json.dump(ack,f)
  temp.rename(target)
  offset+=size
 gz=first_bytes+b''.join((out/('part-%03d.bin'%x[0])).read_bytes() for x in rows)
 assert len(gz)==1896491 and hashlib.sha256(gz).hexdigest()=='093a07b6783299d6bc2e515da39b0db62c925f3b89df1584181c821897890fba'
 with (out/'uma-sim-api-205178.gz').open('xb') as f:f.write(gz)
 binary=gzip.decompress(gz)
 assert len(binary)==4820584 and hashlib.sha256(binary).hexdigest()=='1eb09106a85924eaccc70237300c59e62e8215608cc668c097c0b2237a48c814'
 p=out/'uma-sim-api'
 with p.open('xb') as f:f.write(binary)
 p.chmod(0o755)
 receipt['gzip']={'bytes':len(gz),'sha256':hashlib.sha256(gz).hexdigest()}
 receipt['binary']={'path':str(p),'bytes':len(binary),'sha256':hashlib.sha256(binary).hexdigest()}
 receipt['status']='verified'
except BaseException as e:
 receipt['status']='failed';receipt['error']=repr(e);receipt['traceback']=traceback.format_exc()
finally:
 receipt['end_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (out/'root-shared-receiving-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
