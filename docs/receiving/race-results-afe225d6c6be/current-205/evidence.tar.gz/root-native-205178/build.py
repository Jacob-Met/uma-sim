import pathlib,json,hashlib,gzip,tarfile,subprocess,os,time,traceback,shutil,tomllib
root=pathlib.Path(__file__).parent
parent=root.parent
repository=parent/'reference'
metadata=parent/'api-shared-receiving-205178-r4/metadata'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,o):(root/name).write_text(json.dumps(o,indent=2)+'\n')
receipt={'status':'preparing','reason':'Root receiving namespace requires an executable; completed sender artifact remains unavailable across full shared storage. Reuse exactly pinned local source/cache without network or installations.','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source':'205178f1bf3bf5f34c04bbda88c3e4df2102f535','tree':'a0458be13b0a43575361e2fb8f9385f222683971'}
try:
 assert shutil.disk_usage(root).free>1024**3
 inventory_raw=gzip.decompress((metadata/'source-pins.json.gz').read_bytes())
 inventory=json.loads(inventory_raw)
 assert inventory['source_commit']==receipt['source'] and inventory['source_tree']==receipt['tree']
 assert subprocess.check_output(['git','rev-parse',receipt['source']+'^{tree}'],cwd=repository,text=True).strip()==receipt['tree']
 source=root/'source';source.mkdir()
 ap=subprocess.Popen(['git','archive','--format=tar',receipt['source']],cwd=repository,stdout=subprocess.PIPE)
 seen=set()
 with tarfile.open(fileobj=ap.stdout,mode='r|') as tf:
  for m in tf:
   if m.isdir():continue
   assert m.isfile() and m.name in inventory['files']
   rel=pathlib.PurePosixPath(m.name);assert not rel.is_absolute() and '..' not in rel.parts
   data=tf.extractfile(m).read();pin=inventory['files'][m.name]
   assert len(data)==pin['bytes'] and sha(data)==pin['sha256']
   dst=source/m.name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);dst.chmod(0o755 if pin['mode']=='100755' else 0o644)
   seen.add(m.name)
 assert ap.wait()==0 and seen==set(inventory['files'])
 cache=json.loads((metadata/'cache-receipt.json').read_text())
 donor=pathlib.Path(cache['donor']);cargo_home=root/'cargo-home';cargo_home.mkdir()
 checksums={p['name']+'-'+p['version']+'.crate':p['checksum'] for p in tomllib.loads((source/'Cargo.lock').read_text())['package'] if p.get('source','').startswith('registry+')}
 for p in cache['archives']+cache['index_records']:
  data=(donor/p['path']).read_bytes();assert len(data)==p['bytes'] and sha(data)==p['sha256']
  if p in cache['archives']:assert sha(data)==checksums[pathlib.Path(p['path']).name]
  dst=cargo_home/p['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 (root/'cache-receipt.json').write_bytes((metadata/'cache-receipt.json').read_bytes())
 (root/'source-pins.json.gz').write_bytes((metadata/'source-pins.json.gz').read_bytes())
 base=json.loads((metadata/'build-receipt.json').read_text())
 toolchain=pathlib.Path(base['command'][0]).parent
 assert sha((toolchain/'cargo').read_bytes())==base['compiler']['cargo_sha256']
 assert sha((toolchain/'rustc').read_bytes())==base['compiler']['rustc_sha256']
 overrides={'CARGO_HOME':str(cargo_home),'CARGO_TARGET_DIR':str(root/'target'),'RUSTC':str(toolchain/'rustc'),'RUSTDOC':str(toolchain/'rustdoc'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_RELEASE_DEBUG':'0','CARGO_PROFILE_RELEASE_STRIP':'symbols','TMPDIR':str(root/'tmp')}
 (root/'tmp').mkdir()
 env=os.environ.copy();env.update(overrides)
 assert not env.get('RUSTC_WRAPPER') and not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
 command=[str(toolchain/'cargo'),'build','--locked','--offline','--release','--package','uma-sim-core','--bin','uma-sim-api']
 receipt.update(status='building',compiler=base['compiler'],command=command,environment=overrides,source_files=len(seen),source_bytes=inventory['source_bytes'],source_inventory_sha256=sha(inventory_raw),cache_manifest_sha256=sha((metadata/'cache-receipt.json').read_bytes()),lock_sha256=sha((source/'Cargo.lock').read_bytes()),driver_sha256=sha(pathlib.Path(__file__).read_bytes()),build_timeout_seconds=180)
 dump('build-preflight.json',receipt)
 started=time.monotonic()
 with (root/'build-release.log').open('xb') as log:result=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 receipt['elapsed_seconds']=time.monotonic()-started;receipt['exit_code']=result.returncode
 assert result.returncode==0
 for name,p in inventory['files'].items():
  data=(source/name).read_bytes()
  assert len(data)==p['bytes'] and sha(data)==p['sha256'],name
 binary=(root/'target/release/uma-sim-api').read_bytes();assert binary[:4]==b'\x7fELF'
 retained=root/'uma-sim-api';retained.write_bytes(binary);retained.chmod(0o500)
 receipt.update(status='verified',all_source_bytes_unchanged=True,binary={'path':str(retained),'bytes':len(binary),'sha256':sha(binary)},sender_binary_sha256=base['executable']['sha256'],same_bytes_as_sender=sha(binary)==base['executable']['sha256'],build_log_sha256=sha((root/'build-release.log').read_bytes()),limits='Native build and source provenance; full-App browser acceptance is separate.')
except BaseException as e:
 receipt.update(status='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 receipt['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());dump('root-native-build-receipt.json',receipt)
