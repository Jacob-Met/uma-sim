from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
root=Path('/dev/uma-root-afe225d6c6be');repo=root/'reference';ui=repo/'packages/uma-sim-ui';out=root/'receiving'
donor=Path('/workspace/scratch/acd057031fb2/agents/coordination/uma-current/packages/uma-sim-ui/node_modules')
primary=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules')
modules=ui/'node_modules';assert modules.is_dir() and not modules.is_symlink()
lock_bytes=(ui/'package-lock.json').read_bytes();lock=json.loads(lock_bytes)
(out/'dependency-setup-r1-failure.json').write_bytes(json.dumps(json.loads("{\"stage\":\"Owned dependency setup before tests\",\"observed\":{\"chunk_id\":\"4805ea\",\"wall_time_seconds\":1.001569165,\"session_id\":30671,\"original_token_count\":32,\"output\":\"Traceback (most recent call last):\\r\\n  File \\\"<stdin>\\\", line 18, in <module>\\r\\nKeyError: 'node_modules/object-assign'\\r\\nUMA_ROOT> \"},\"cause\":\"Donor had unlocked packages including object-assign; direct dictionary lookup stopped setup. No tests, typecheck, build, source edit, donor edit, or .bin creation ran.\",\"correction\":\"Select only packages present in target lock; validate all previously created symlinks against expected donor; retain owned root and resume. Versions and manifest hashes recorded.\"}"),indent=2,sort_keys=True).encode()+bytes([10]))
packages=[]
for p in sorted(donor.iterdir()):
 if p.name.startswith('@') and p.is_dir():
  packages.extend((p.name+'/'+q.name,q) for q in sorted(p.iterdir()) if (q/'package.json').is_file())
 elif not p.name.startswith('.') and (p/'package.json').is_file() and p.name not in ['playwright','playwright-core']:
  packages.append((p.name,p))
packages.extend((name,primary/name) for name in ['playwright','playwright-core'])
excluded=[name for name,p in packages if 'node_modules/'+name not in lock['packages']]
packages=[(name,p) for name,p in packages if 'node_modules/'+name in lock['packages']]
assert len(packages)==71,len(packages)
expected={name:p for name,p in packages}
for p in modules.rglob('*'):
 if p.is_symlink():
  name=str(p.relative_to(modules));assert name in expected and p.readlink()==expected[name],(name,str(p.readlink()))
receipts=[]
for name,p in packages:
 body=(p/'package.json').read_bytes();meta=json.loads(body);pin=lock['packages']['node_modules/'+name]
 assert meta['version']==pin['version'],(name,meta['version'],pin['version'])
 target=modules/name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.is_symlink():assert target.readlink()==p
 else:
  assert not target.exists();target.symlink_to(p,target_is_directory=True)
 receipts.append({'name':name,'version':meta['version'],'packageManifestSha256':hashlib.sha256(body).hexdigest(),'donor':str(p),'lockIntegrity':pin.get('integrity')})
assert len(receipts)==71,len(receipts)
bins=modules/'.bin';bins.mkdir()
(bins/'tsc').symlink_to('../typescript/bin/tsc')
(bins/'vite').symlink_to('../vite/bin/vite.js')
dep={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'lockSha256':hashlib.sha256(lock_bytes).hexdigest(),'packages':receipts,'count':len(receipts),'excludedDonorExtras':excluded,'scope':'Owned symlink root and .bin only; donor packages read-only. Actual71 installed versions match the locked dependencies; no npm install, dependency declaration or lock change.'}
(out/'ui-dependencies.json').write_bytes(json.dumps(dep,indent=2,sort_keys=True).encode()+bytes([10]))
cache=ui/'tsconfig.tsbuildinfo';cache_before=cache.read_bytes()
(out/'tsconfig.tsbuildinfo.before').write_bytes(cache_before)
env=os.environ.copy();tmp=root/'tmp';tmp.mkdir(exist_ok=True);env['TMPDIR']=str(tmp)
results=[]
for name,command in [('ui-tests',['npm','test']),('ui-typecheck',['npm','run','typecheck']),('ui-build',['npm','run','build'])]:
 start=datetime.now(timezone.utc).isoformat()
 print(json.dumps({'stepStarted':name}),flush=True)
 result=subprocess.run(command,cwd=ui,env=env,capture_output=True,text=True)
 body=result.stdout+result.stderr;p=out/(name+'.log');p.write_text(body)
 results.append({'name':name,'command':command,'started_at_utc':start,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exitCode':result.returncode,'log':str(p),'logSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 if result.returncode!=0:break
cache_after=cache.read_bytes();(out/'tsconfig.tsbuildinfo.after').write_bytes(cache_after)
diff=subprocess.check_output(['git','diff','--','packages/uma-sim-ui/tsconfig.tsbuildinfo'],cwd=repo);(out/'tsconfig-build-side-effect.patch').write_bytes(diff)
cache.write_bytes(cache_before);assert cache.read_bytes()==cache_before
changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
assert not changed,changed
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
tree=subprocess.check_output(['git','write-tree'],cwd=repo,text=True).strip()
assert head=='ce9f654f4ecb805940edcb4b6b0151a3f4d4b381' and tree=='87fda7cdc403c82a789154a5d860b88fbc285599'
for e in receipts:
 assert hashlib.sha256((Path(e['donor'])/'package.json').read_bytes()).hexdigest()==e['packageManifestSha256'],e['name']
distribution=[]
if (ui/'dist').exists():
 for p in sorted((ui/'dist').rglob('*')):
  if p.is_file():
   b=p.read_bytes();distribution.append({'path':str(p.relative_to(ui/'dist')),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
receipt={'kind':'uma-race-current-native-ui-receiving','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'sourceHead':head,'sourceTree':tree,'base':'f27829a266bb39fb1a4f298e2c2b3b32f380af0f','node':subprocess.check_output(['node','--version'],text=True).strip(),'results':results,'dependencyPackages':71,'lockSha256':dep['lockSha256'],'trackedBuildCache':{'path':'packages/uma-sim-ui/tsconfig.tsbuildinfo','beforeSha256':hashlib.sha256(cache_before).hexdigest(),'afterSha256':hashlib.sha256(cache_after).hexdigest(),'generatedDifferentBytes':cache_after!=cache_before,'originalAndGeneratedPreserved':True,'originalRestored':True},'sourceUnchangedAfterReceiving':True,'distribution':distribution,'passed':len(results)==3 and all(e['exitCode']==0 for e in results)}
p=out/'native-ui-receiving.json';b=json.dumps(receipt,indent=2,sort_keys=True).encode()+bytes([10]);p.write_bytes(b)
print(json.dumps({'qualified':receipt['passed'],'receipt':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'source':head,'tree':tree,'steps':[{'name':e['name'],'exitCode':e['exitCode']} for e in results],'testSummary':[l for l in (out/'ui-tests.log').read_text().splitlines() if l.startswith(('# tests','# pass','# fail','# skipped','# duration','# cancelled','# todo'))],'distribution':distribution,'cacheRestored':True}),flush=True)

