# Independent Uma retained race results receiving

Frozen before candidate inspection on 2026-10-08. Receiver: `engine_execution`; author: `product_execution`; integration and publication: root. Repository: `Jacob-Met/uma-sim`; scope: issue #86. This is a receiving contract and planned controls, not a claim that unexecuted checks passed.

## Source and authority

The actual receiving base is commit `4dc00f155d29fb37887524455f0627399191c915`, tree `10bfb5a88f9dd436534bb01c281ec55c50268b29`. The immutable Git object donor is `/dev/shm/hamon-afe225d6c6be-product/uma-sim`; use `git archive` of that commit, because its initial working checkout was interrupted by exhausted storage. The baseline includes Event Log #80. Its current `App.tsx` passes `state.textLines` to RacePanel and separately passes `cs.log` to LogPanel. The receiver does not take over Event Log or request/session routing.

The author's earlier user/data contract remains immutable at SHA-256 `8b0c7b79e03aedebb8d383c8df8fe6bd94e6890ff366658ec900264d3888a71b`. The core, race, renderer, API and lock blobs in that contract remain the native authority on the actual receiving base:

| Source | Git blob |
| --- | --- |
| `uma-sim-core/src/engine.rs` | `7ece3123aea3ba3f17326ceb033fc53e796b3566` |
| `uma-sim-core/src/race.rs` | `0a4587f5dc7f50aff3005ebd46abc01ef3756c43` |
| `uma-sim-core/src/render.rs` | `3f154753f700fa4a6faccf19faf8bfe320143137` |
| `uma-sim-core/src/api.rs` | `eab9ccf7082ffc96c446f434bd76f313aff14bc9` |
| `Cargo.lock` | `1f99851c45524f129e8544a2d779b3c21594d816` |
| inherited `RacePanel.tsx` | `9bbb87b3d1d71272b44031552aa053fdc4067469` |

Source inspection establishes that retained physics records have `Race <id> <ordinal> +<gain> fans [physics t=<seconds>s course=<id> seed=<seed> field=<size> margin_win=<seconds>s margin_ahead=<seconds>s]`. Stub records retain only `Race <id> +<gain> fans`. Native action text has a different grammar, and the later current-state text does not replay retained race records. These are reasons to verify against `state.log`, not sufficient positive execution evidence by themselves.

## Frozen native capture plan

Run an exact-base Linux `uma-sim-api` built with the existing locked toolchain/dependency closure, without embedded UI, in an owned temporary directory. Bind only loopback on an independently allocated port. Use the verified archived repository as `UMA_REPO_ROOT`; keep `.uma-sim` storage in the receiver's own process working directory. No live services, accounts, forks, library saves, external policy provider, or shared process are needed.

Independently selected careers: physics seed `-317`, and stub seed `771`, both `ura`, `SpecialWeek`, speed `1`, dialogue `off`, policy `default`. Capture start, choices, action responses, state and text. Select actual offered `race` choices until at least two race records exist, use an offered event choice when needed, and take a later offered ordinary action. Preserve the exact literal retained lines and their enclosing native snapshots. If the actual choice flow requires an extra step, record the observed flow rather than manufacturing state or a positive line. Capture a naturally reached mandatory-race state for the inherited Enter race/busy control.

Freeze this native annex, its command/request transcript, native source/binary pins and hashes before inspecting candidate code. Label synthetic boundary fixtures separately from these actual native lines. The baseline witness must show that the old RacePanel cannot render these real physics records through its current prop/parser; a real stub line must expose its invented `1 place` behavior.

## User-visible receiving invariants

1. After two actual physics races and a later ordinary action, the latest result and every retained race occurrence remain available from the current snapshot. Displayed position, field size, finish time, fan gain, course, race seed and both margins, when displayed, agree with the same literal native record. Units describe seconds, fans and field/place appropriately; no cross-record mixture is acceptable.
2. Retained race order determines recency. Repeated IDs and byte-identical repeated records remain distinct occurrences. A newer unknown `Race` record is the newest record and cannot silently promote an older parseable result. Ordinary log text does not manufacture a race.
3. Actual stub output admits only its recorded ID/fan gain. It supplies no place, field, finish time, course, race seed or margins. Unknown/malformed records remain accessible verbatim with an honest unavailable/unrecognized explanation, not fabricated numerical facts.
4. Numeric parsing must consume valid complete fields and preserve finite values. Fractional or nonpositive field sizes, place zero or beyond the field, invalid ordinal grammar, missing/truncated fields and nonfinite/overflow values cannot produce a recognized physics result. Do not infer facts from present settings, current stats, prior results or the stub engine's implementation branch.
5. The supplied log is the current career's authority. Rendering a different log, a stub-only log and an empty log removes prior results; no component-local archive may leak across supplied snapshots.
6. Literal Unicode, markup and long record strings remain text and wrap within narrow layout. Raw details expose the complete record without interpreting tags, event attributes or URLs.
7. History/details review issues no career action requests and changes no current native state. The existing mandatory-race callback remains available when appropriate, is disabled while busy, and invokes the callback once on deliberate activation. No new unrelated API, storage or session behavior is within this source scope.
8. Browser observations include keyboard access to history and literal detail disclosures, visible focus, a 390 px viewport, no horizontal document overflow, and a desktop view. The interface describes retained records and does not promise a complete career archive.

## Execution and evidence boundary

`synthetic-cases.json` is frozen alongside this contract. It records expected user facts independently of the candidate's function names or DOM selectors. Receiver bindings may be authored after the source freezes, but must not weaken these cases to match implementation. Any ambiguity, driver correction, source failure, or contract clarification remains in an additive receipt with the original evidence preserved.

A small standalone component harness will isolate synthetic malformed/unknown/prop-replacement cases from the real engine. Actual native positive lines will also be rendered through that component. The built application will be served with a loopback proxy to the receiver's own real native API for retained-history/ordinary-action/mandatory/read-only observations. External asset requests, if inherited, will be recorded and blocked; they are not necessary for result receiving. Source review checks the exact one-prop App integration and confirms that Event Log, engine, API, catalogs and settings bytes are untouched.

Run meaningful targeted receiver controls in addition to the author's native suite; do not repeat unrelated comprehensive career, lab, trace, Event Log or engine suites. Freeze exact candidate source hashes, test/harness hashes, native input hashes, browser observations and any actual failure before sending an acceptance conclusion.
