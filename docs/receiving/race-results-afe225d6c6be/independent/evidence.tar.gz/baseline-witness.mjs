// SPDX-License-Identifier: GPL-3.0-only
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, mkdtemp, symlink } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';

const [sourceRoot, outputPath] = process.argv.slice(2);
assert(sourceRoot && outputPath, 'usage: node baseline-witness.mjs EXACT_BASE_SOURCE OUTPUT_JSON');
const dependencyRequire = createRequire('/workspace/scratch/acd057031fb2/agents/coordination/uma-current/packages/uma-sim-ui/package.json');
const React = dependencyRequire('react');
const { renderToStaticMarkup } = dependencyRequire('react-dom/server');
const ts = dependencyRequire('typescript');
const temporary = await mkdtemp('/dev/hamon-afe225d6c6be-uma-baseline-component-');
await mkdir(path.join(temporary, 'node_modules'));
await symlink(path.dirname(dependencyRequire.resolve('react/package.json')), path.join(temporary, 'node_modules/react'));
const relative = 'packages/uma-sim-ui/src/components/RacePanel.tsx';
const source = await readFile(path.join(sourceRoot, relative), 'utf8');
const blob = createHash('sha1').update(Buffer.from(`blob ${Buffer.byteLength(source)}\0`)).update(source).digest('hex');
assert.equal(blob, '9bbb87b3d1d71272b44031552aa053fdc4067469');
const { outputText } = ts.transpileModule(source, {
  fileName: 'RacePanel.tsx',
  compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX },
});
await writeFile(path.join(temporary, 'RacePanel.cjs'), outputText, { flag: 'wx' });
const require = createRequire(import.meta.url);
const { RacePanel, parseRaceResult } = require(path.join(temporary, 'RacePanel.cjs'));
const nativeText = await readFile('/dev/shm/hamon-afe225d6c6be-engine-uma-review/native-r1/native-inputs.json', 'utf8');
const native = JSON.parse(nativeText);
assert.equal(native.status, 'PASS');
const markup = lines => renderToStaticMarkup(React.createElement(RacePanel, { lines, mandatory: false, busy: false, onRace: () => { throw Error('a static render must not act'); } }));
const actualPhysicsLog = native.physics.afterOrdinary.snapshot.state.log;
const currentTextLines = native.physics.afterOrdinary.text.split('\n').filter(Boolean);
assert.equal(parseRaceResult(actualPhysicsLog), null, 'inherited parser cannot admit actual retained physics lines');
assert.equal(markup(actualPhysicsLog), '', 'a prop-only repair would still hide these actual physics records');
assert.equal(markup(currentTextLines), '', 'inherited current-text prop has no surviving race results');
const stubLine = native.stub.records.at(-1).raw;
const stubParse = parseRaceResult([stubLine]);
assert.equal(stubParse.place, '1', 'inherited stub parser invents first place');
const stubMarkup = markup([stubLine]);
assert.match(stubMarkup, /1 place/);
const app = await readFile(path.join(sourceRoot, 'packages/uma-sim-ui/src/App.tsx'), 'utf8');
assert.match(app, /<RacePanel\s+lines=\{state\.textLines\}/);
const receipt = {
  status: 'REPRODUCED', base: native.sourceBase, tree: native.sourceTree,
  component: { path: relative, gitBlob: blob, sha256: createHash('sha256').update(source).digest('hex') },
  dependencyVersions: { node: process.version, react: dependencyRequire('react/package.json').version, reactDom: dependencyRequire('react-dom/package.json').version, typescript: ts.version },
  nativeInputsSha256: createHash('sha256').update(nativeText).digest('hex'),
  physics: { rawRecords: native.physics.records.map(record => record.raw), laterCurrentText: native.physics.afterOrdinary.text, parseResult: null, renderedMarkup: '' },
  stub: { raw: stubLine, actualRecordedFields: ['raceId', 'fans'], inheritedParse: stubParse, inheritedMarkup: stubMarkup },
  conclusions: ['Current App prop and inherited parser each independently hide actual retained physics results.', 'A real native stub record produces invented first-place markup in the inherited component.'],
};
await writeFile(outputPath, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(receipt));
