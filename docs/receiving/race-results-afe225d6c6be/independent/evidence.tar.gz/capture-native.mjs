// SPDX-License-Identifier: GPL-3.0-only
// Independent receiver. Inputs and seeds were selected before candidate inspection.
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:net';
import path from 'node:path';

const [binaryArg, sourceArg, outputArg] = process.argv.slice(2);
assert(binaryArg && sourceArg && outputArg, 'usage: node capture-native.mjs EXACT_API_BINARY VERIFIED_SOURCE OUTPUT_DIRECTORY');
const binary = path.resolve(binaryArg);
const source = path.resolve(sourceArg);
const output = path.resolve(outputArg);
await mkdir(output, { recursive: true });
const runtime = await mkdtemp('/dev/hamon-afe225d6c6be-uma-independent-api-');
const socket = createServer();
await new Promise((resolve, reject) => { socket.once('error', reject); socket.listen(0, '127.0.0.1', resolve); });
const port = socket.address().port;
await new Promise((resolve, reject) => socket.close(error => error ? reject(error) : resolve()));
const origin = `http://127.0.0.1:${port}`;
const nativeEnv = { ...process.env, UMA_REPO_ROOT: source };
delete nativeEnv.UMA_POLICY_CMD;
const native = spawn(binary, [String(port)], {
  cwd: runtime,
  env: nativeEnv,
  stdio: ['ignore', 'pipe', 'pipe'],
});
let stdout = '', stderr = '';
native.stdout.on('data', chunk => { stdout = (stdout + chunk).slice(-65536); });
native.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-65536); });
let processError;
native.on('error', error => { processError = String(error); });
const transcript = [];
async function request(method, endpoint, body) {
  const response = await fetch(origin + endpoint, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(15000),
  });
  const text = await response.text();
  let json;
  try { json = JSON.parse(text); } catch { json = null; }
  transcript.push({ method, endpoint, ...(body ? { body } : {}), status: response.status, response: json ?? text });
  assert.equal(response.status, 200, `${method} ${endpoint}: ${text}`);
  assert(json && typeof json === 'object', 'JSON object response');
  return json;
}
const raceLines = snapshot => snapshot.state.log.filter(line => line.startsWith('Race '));
const ordinal = value => {
  const tail = value % 100;
  const suffix = tail >= 11 && tail <= 13 ? 'th' : ({ 1: 'st', 2: 'nd', 3: 'rd' }[value % 10] ?? 'th');
  return `${value}${suffix}`;
};
function nativeFacts(line, model) {
  if (model === 'stub') {
    const match = /^Race (\S+) \+(\d+) fans$/.exec(line);
    assert(match, `exact native stub shape: ${line}`);
    return { raw: line, model, raceId: match[1], fans: Number(match[2]) };
  }
  const match = /^Race (\S+) (\d+)(st|nd|rd|th) \+(\d+) fans \[physics t=(\d+\.\d{3})s course=(\S+) seed=(\d+) field=(\d+) margin_win=(\d+\.\d{3})s margin_ahead=(\d+\.\d{3})s\]$/.exec(line);
  assert(match, `exact native physics shape: ${line}`);
  const facts = { raw: line, model, raceId: match[1], place: Number(match[2]), ordinal: match[2] + match[3], fans: Number(match[4]), finishSeconds: Number(match[5]), course: match[6], seed: Number(match[7]), field: Number(match[8]), marginWinSeconds: Number(match[9]), marginAheadSeconds: Number(match[10]) };
  assert.equal(facts.ordinal, ordinal(facts.place));
  assert(facts.place > 0 && facts.place <= facts.field);
  for (const value of Object.values(facts).filter(value => typeof value === 'number')) assert(Number.isFinite(value));
  return facts;
}
async function career(model, seed, captureMandatory) {
  const start = { seed: String(seed), scenario: 'ura', trainee: 'SpecialWeek', speed: '1', dialogue: 'off', raceModel: model, policy: 'default' };
  let snapshot = await request('POST', '/v1/run/start', start);
  assert.equal(snapshot.meta.seed, seed);
  assert.equal(snapshot.settings.raceModel, model);
  const initial = snapshot;
  const actions = [];
  let firstMandatory = null;
  for (let index = 0; index < 32 && raceLines(snapshot).length < 2; index++) {
    const choices = (await request('GET', '/v1/run/choices')).choices;
    if (snapshot.state.phase === 'MANDATORY_RACE') firstMandatory ??= snapshot;
    const action = choices.find(choice => choice.id === 'race')?.id ?? choices.find(choice => /^event_\d+$/.test(choice.id))?.id;
    assert(action, `expected an offered race or event choice: ${JSON.stringify(choices)}`);
    const response = await request('POST', '/v1/run/action', { action });
    actions.push({ action, turnBefore: snapshot.state.turn, phaseBefore: snapshot.state.phase, response });
    snapshot = response.state;
  }
  assert(raceLines(snapshot).length >= 2, 'at least two real race records');
  const afterRaces = snapshot;
  let ordinary;
  for (let index = 0; index < 32 && !ordinary; index++) {
    const choices = (await request('GET', '/v1/run/choices')).choices;
    if (snapshot.state.phase === 'MANDATORY_RACE') firstMandatory ??= snapshot;
    const action = choices.find(choice => choice.id === 'rest')?.id ?? choices.find(choice => /^event_\d+$/.test(choice.id))?.id ?? choices.find(choice => choice.id === 'race')?.id;
    assert(action, 'an offered ordinary step or gate resolver');
    const response = await request('POST', '/v1/run/action', { action });
    actions.push({ action, turnBefore: snapshot.state.turn, phaseBefore: snapshot.state.phase, response });
    if (action === 'rest') ordinary = { before: snapshot, response };
    snapshot = response.state;
  }
  assert(ordinary, 'actual offered rest after the races');
  const laterState = await request('GET', '/v1/run/state');
  assert.deepEqual(laterState, snapshot, 'same native state via action and state routes');
  const laterText = await request('GET', '/v1/run/text');
  assert(raceLines(laterState).length >= 2);
  for (const line of raceLines(afterRaces)) assert(laterState.state.log.includes(line), 'ordinary action retains actual record');
  const laterChoices = await request('GET', '/v1/run/choices');
  const afterOrdinary = { snapshot: laterState, text: laterText.text, choices: laterChoices.choices };
  if (captureMandatory && !firstMandatory) {
    for (let index = 0; index < 120 && !firstMandatory; index++) {
      if (snapshot.state.phase === 'MANDATORY_RACE') { firstMandatory = snapshot; break; }
      const choices = (await request('GET', '/v1/run/choices')).choices;
      const action = choices.find(choice => choice.id === 'rest')?.id ?? choices.find(choice => /^event_\d+$/.test(choice.id))?.id;
      assert(action, `bounded mandatory capture has a legal ordinary/event action: ${JSON.stringify(choices)}`);
      const response = await request('POST', '/v1/run/action', { action });
      actions.push({ action, turnBefore: snapshot.state.turn, phaseBefore: snapshot.state.phase, response });
      snapshot = response.state;
    }
    assert(firstMandatory, 'naturally reached mandatory state within 120 offered steps');
  }
  return { model, seed, start, initial, actions, afterRaces, ordinary, afterOrdinary, firstMandatory, records: raceLines(afterOrdinary.snapshot).map(line => nativeFacts(line, model)) };
}

const started = new Date().toISOString();
let receipt;
try {
  let ready = false;
  for (let attempt = 0; attempt < 100 && !ready; attempt++) {
    assert(!processError, processError);
    assert(native.exitCode === null, `native API exited: ${native.exitCode}; ${stderr}`);
    try {
      const response = await fetch(origin + '/v1/health', { signal: AbortSignal.timeout(1000) });
      ready = response.ok;
    } catch { /* waiting for this owned child only */ }
    if (!ready) await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert(ready, 'native API became ready');
  const health = await request('GET', '/v1/health');
  assert.equal(health.repoRoot, true, 'native catalogs use detected exact source');
  const physics = await career('physics', -317, true);
  const stub = await career('stub', 771, false);
  receipt = { status: 'PASS', started, finished: new Date().toISOString(), sourceBase: '4dc00f155d29fb37887524455f0627399191c915', sourceTree: '10bfb5a88f9dd436534bb01c281ec55c50268b29', binary, binarySha256: createHash('sha256').update(await readFile(binary)).digest('hex'), source, runtime, health, physics, stub };
} catch (error) {
  receipt = { status: 'FAIL', started, finished: new Date().toISOString(), error: String(error), stack: error?.stack, transcriptCount: transcript.length, stdout, stderr };
  process.exitCode = 1;
} finally {
  native.kill('SIGTERM');
  await Promise.race([new Promise(resolve => native.once('exit', resolve)), new Promise(resolve => setTimeout(resolve, 1500))]);
  if (native.exitCode === null && native.signalCode === null) native.kill('SIGKILL');
  await writeFile(path.join(output, 'native-inputs.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
  await writeFile(path.join(output, 'native-transcript.json'), JSON.stringify(transcript, null, 2) + '\n', { flag: 'wx' });
  await writeFile(path.join(output, 'native-process.json'), JSON.stringify({ stdout, stderr, exitCode: native.exitCode, signalCode: native.signalCode }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ status: receipt.status, error: receipt.error, output, physicsRecords: receipt.physics?.records, stubRecords: receipt.stub?.records, mandatoryTurn: receipt.physics?.firstMandatory?.state.turn, requests: transcript.length }));
}
