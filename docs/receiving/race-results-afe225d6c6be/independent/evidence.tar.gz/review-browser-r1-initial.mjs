// SPDX-License-Identifier: GPL-3.0-only
// Independent browser receiver, bound to cases frozen before candidate inspection.
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { createServer as createHttpServer } from 'node:http';
import { createServer as createNetServer } from 'node:net';
import { createRequire } from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [sourceRootArg, binaryArg, outputArg] = process.argv.slice(2);
assert(sourceRootArg && binaryArg && outputArg, 'usage: node review-browser.mjs FROZEN_SOURCE EXACT_API_BINARY OUTPUT_DIRECTORY');
const sourceRoot = path.resolve(sourceRootArg);
const binary = path.resolve(binaryArg);
const output = path.resolve(outputArg);
const ui = path.join(sourceRoot, 'packages/uma-sim-ui');
const owned = '/dev/shm/hamon-afe225d6c6be-engine-uma-review';
const temp = await mkdtemp('/dev/hamon-afe225d6c6be-uma-browser-receiver-');
await mkdir(output, { recursive: true });
await mkdir(path.join(temp, 'runtime'));
const require = createRequire(path.join(ui, 'package.json'));
const esbuild = require('esbuild');
const { chromium } = await import(pathToFileURL(require.resolve('playwright')).href);
const fixtureBytes = await readFile(path.join(owned, 'synthetic-cases.json'));
assert.equal(createHash('sha256').update(fixtureBytes).digest('hex'), 'a23a69ef0379871f278a074482c49ed516235396cc7acc671858cb648c087b29');
const cases = JSON.parse(fixtureBytes);
const nativeBytes = await readFile(path.join(owned, 'native-r1/native-inputs.json'));
assert.equal(createHash('sha256').update(nativeBytes).digest('hex'), '3e818210db693d76225d7157e36f37fbc1294d7a4f820d78db84d63db3cd91d6');
const nativeInputs = JSON.parse(nativeBytes);
const fixtureSource = `
import React from 'react';
import { createRoot } from 'react-dom/client';
import { RacePanel } from './src/components/RacePanel';
import './src/styles/app.css';
const root=createRoot(document.getElementById('fixture-root'));
window.__reviewCalls=[];
window.__reviewRender=async props=>{
  root.render(<RacePanel lines={[]} mandatory={false} busy={false} {...props} onRace={()=>window.__reviewCalls.push('race')}/>);
  await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
};
window.__reviewReady=true;
`;
const built = await esbuild.build({
  stdin: { contents: fixtureSource, loader: 'tsx', sourcefile: 'independent-review.tsx', resolveDir: ui },
  absWorkingDir: ui, bundle: true, write: false, platform: 'browser', format: 'esm',
  outdir: path.join(temp, 'fixture'), entryNames: 'fixture', sourcemap: false,
  define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'silent',
});
const fixtureAssets = new Map(built.outputFiles.map(file => [path.basename(file.path), file.contents]));
assert(fixtureAssets.has('fixture.js') && fixtureAssets.has('fixture.css'));
const fixtureHtml = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Independent Uma race component receiving</title><link rel="stylesheet" href="fixture.css"><body><main class="app" style="max-width:850px;margin:auto;padding:16px"><button id="review-before">Before race panel</button><div id="fixture-root" style="margin:16px 0"></div><button id="review-after">After race panel</button></main><script type="module" src="fixture.js"></script></body></html>';

const reserve = createNetServer();
await new Promise((resolve, reject) => { reserve.once('error', reject); reserve.listen(0, '127.0.0.1', resolve); });
const nativePort = reserve.address().port;
await new Promise(resolve => reserve.close(resolve));
const nativeOrigin = `http://127.0.0.1:${nativePort}`;
const nativeEnv = { ...process.env, UMA_REPO_ROOT: sourceRoot };
delete nativeEnv.UMA_POLICY_CMD;
const child = spawn(binary, [String(nativePort)], { cwd: path.join(temp, 'runtime'), env: nativeEnv, stdio: ['ignore', 'pipe', 'pipe'] });
let nativeStdout = '', nativeStderr = '';
child.stdout.on('data', data => { nativeStdout = (nativeStdout + data).slice(-65536); });
child.stderr.on('data', data => { nativeStderr = (nativeStderr + data).slice(-65536); });
const apiTranscript = [];
const browserRequests = [];
const externalRequests = [];
const pageErrors = [];
const groups = [];
let actionDelay = null;
let releaseAction = null;
async function api(endpoint, method = 'GET', body) {
  const response = await fetch(nativeOrigin + endpoint, { method, headers: body ? { 'Content-Type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(15000) });
  const text = await response.text();
  assert.equal(response.status, 200, `${method} ${endpoint}: ${text}`);
  const data = JSON.parse(text);
  apiTranscript.push({ method, endpoint, body, response: data });
  return data;
}
const contentTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const server = createHttpServer(async (request, response) => {
  try {
    const requestUrl = new URL(request.url, 'http://127.0.0.1');
    if (requestUrl.pathname.startsWith('/v1/')) {
      const chunks = [];
      for await (const chunk of request) chunks.push(chunk);
      const body = Buffer.concat(chunks);
      const entry = { method: request.method, endpoint: request.url, body: body.length ? JSON.parse(body.toString()) : null };
      browserRequests.push(entry);
      if (requestUrl.pathname === '/v1/run/action' && actionDelay) { const held = actionDelay; actionDelay = null; await held; }
      const upstream = await fetch(nativeOrigin + request.url, { method: request.method, headers: body.length ? { 'Content-Type': 'application/json' } : undefined, body: body.length ? body : undefined });
      const bytes = Buffer.from(await upstream.arrayBuffer());
      entry.status = upstream.status;
      response.writeHead(upstream.status, { 'Content-Type': upstream.headers.get('content-type') ?? 'application/json' });
      response.end(bytes);
      return;
    }
    if (requestUrl.pathname === '/__review/' || requestUrl.pathname === '/__review/index.html') {
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); response.end(fixtureHtml); return;
    }
    if (requestUrl.pathname.startsWith('/__review/')) {
      const name = path.basename(requestUrl.pathname);
      if (!fixtureAssets.has(name)) { response.writeHead(404); response.end('Missing receiver asset'); return; }
      response.writeHead(200, { 'Content-Type': contentTypes[path.extname(name)] }); response.end(fixtureAssets.get(name)); return;
    }
    const relative = requestUrl.pathname === '/' ? 'index.html' : decodeURIComponent(requestUrl.pathname).replace(/^\/+/, '');
    const file = path.resolve(ui, 'dist', relative);
    assert(file.startsWith(path.resolve(ui, 'dist') + path.sep), 'static path stays in owned built output');
    const bytes = await readFile(file);
    response.writeHead(200, { 'Content-Type': contentTypes[path.extname(file)] ?? 'application/octet-stream' }); response.end(bytes);
  } catch (error) { response.writeHead(500, { 'Content-Type': 'text/plain' }); response.end(String(error)); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
let browser;
const started = new Date().toISOString();
const facts = line => {
  const match = /^Race (\S+) (\d+)(st|nd|rd|th) \+(\d+) fans \[physics t=(\d+\.\d{3})s course=(\d+) seed=(\d+) field=(\d+) margin_win=(\d+\.\d{3})s margin_ahead=(\d+\.\d{3})s\]$/.exec(line);
  assert(match, `actual native physics line shape: ${line}`);
  return { 'Place': match[2] + match[3], 'Field size': match[8], 'Finish time': match[5] + ' s', 'Fan gain': '+' + match[4] };
};
try {
  let ready = false;
  for (let attempt = 0; attempt < 100 && !ready; attempt++) {
    assert.equal(child.exitCode, null, nativeStderr);
    try { ready = (await fetch(nativeOrigin + '/v1/health', { signal: AbortSignal.timeout(500) })).ok; } catch { /* owned child startup */ }
    if (!ready) await new Promise(resolve => setTimeout(resolve, 50));
  }
  assert(ready, 'owned native API ready');
  browser = await chromium.launch({ executablePath: '/workspace/scratch/3e50c5ad22c5/production/browser/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'], env: { ...process.env, TMPDIR: temp } });
  const context = await browser.newContext({ viewport: { width: 1180, height: 850 } });
  await context.route('**/*', route => {
    const url = new URL(route.request().url());
    if (url.origin === origin || ['data:', 'blob:'].includes(url.protocol)) return route.continue();
    externalRequests.push({ url: url.href, type: route.request().resourceType() });
    return route.abort('blockedbyclient');
  });
  const page = await context.newPage();
  page.on('pageerror', error => pageErrors.push(String(error)));
  await page.goto(origin + '/__review/');
  await page.waitForFunction(() => window.__reviewReady === true);
  const render = async (lines, extra = {}) => page.evaluate(props => window.__reviewRender(props), { lines, mandatory: false, busy: false, ...extra });
  const latestFacts = async () => page.locator('.race-latest .race-facts > div').evaluateAll(items => Object.fromEntries(items.map(item => [item.querySelector('dt').textContent, item.querySelector('dd').textContent])));
  const noOverflow = async () => {
    const sizes = await page.evaluate(() => ({ viewport: innerWidth, document: document.documentElement.scrollWidth, body: document.body.scrollWidth }));
    assert(sizes.document <= sizes.viewport && sizes.body <= sizes.viewport, JSON.stringify(sizes));
    return sizes;
  };
  const tabTo = async selector => {
    await page.locator('#review-before').focus();
    for (let count = 0; count < 12; count++) {
      await page.keyboard.press('Tab');
      if (await page.locator(selector).evaluate(element => element === document.activeElement)) return;
    }
    throw Error(`keyboard did not reach ${selector}`);
  };

  await render(nativeInputs.physics.afterOrdinary.snapshot.state.log);
  assert.deepEqual(await latestFacts(), facts(nativeInputs.physics.records.at(-1).raw));
  await tabTo('.race-latest .race-record summary');
  await page.keyboard.press('Enter');
  assert.equal(await page.locator('.race-latest .race-record pre').innerText(), nativeInputs.physics.records.at(-1).raw);
  const focusStyle = await page.locator('.race-latest .race-record summary').evaluate(element => ({ active: element === document.activeElement, focusVisible: element.matches(':focus-visible'), outline: getComputedStyle(element).outlineStyle, width: getComputedStyle(element).outlineWidth }));
  assert(focusStyle.active && focusStyle.focusVisible && focusStyle.outline !== 'none' && parseFloat(focusStyle.width) > 0);
  await page.keyboard.press('Tab');
  assert(await page.locator('.race-history > summary').evaluate(element => element === document.activeElement));
  await page.keyboard.press('Space');
  assert(await page.locator('.race-history').evaluate(element => element.open));
  await page.keyboard.press('Tab');
  await page.keyboard.press('Enter');
  assert.equal(await page.locator('.race-history .race-record pre').innerText(), nativeInputs.physics.records[0].raw);
  assert.deepEqual(await page.evaluate(() => window.__reviewCalls), []);
  assert.equal(browserRequests.filter(request => request.method === 'POST').length, 0);
  groups.push({ id: 'actual_native_component_facts_keyboard_raw_history', status: 'PASS', facts: await latestFacts(), focusStyle, layout: await noOverflow() });

  await render([cases.reference, cases.reference, cases.alternate, cases.unknown]);
  assert.equal(await page.locator('.race-latest .race-result').getAttribute('data-race-kind'), 'unknown');
  assert.equal(await page.locator('.race-latest .race-facts').count(), 0);
  assert.match(await page.locator('.race-panel').innerText(), /4 retained race records/);
  assert.equal(await page.locator('.race-history li').count(), 3);
  assert.deepEqual(await page.locator('.race-history .race-record pre').allTextContents(), [cases.alternate, cases.reference, cases.reference]);
  const replacement = [];
  for (const lines of [[cases.reference, cases.alternate], [cases.stub], []]) {
    await render(lines);
    replacement.push({ input: lines, panels: await page.locator('.race-panel').count(), raw: await page.locator('.race-record pre').allTextContents(), latestFacts: await latestFacts() });
  }
  assert.equal(replacement[0].raw.length, 2);
  assert.deepEqual(replacement[1].raw, [cases.stub]);
  assert.deepEqual(replacement[1].latestFacts, { 'Fan gain': '+137' });
  assert.equal(replacement[2].panels, 0);
  assert.deepEqual(replacement[2].raw, []);
  groups.push({ id: 'unknown_newest_duplicates_and_live_prop_replacement', status: 'PASS', replacement });

  await page.setViewportSize({ width: 390, height: 844 });
  const longUnknown = cases.unknown + ' · ' + '海🏇é'.repeat(320);
  const literal = [...cases.literal_records, longUnknown];
  await render(literal);
  await page.locator('.race-history > summary').evaluate(element => { if (!element.parentElement.open) element.click(); });
  for (const summary of await page.locator('.race-record > summary').all()) {
    await summary.focus();
    if (!(await summary.evaluate(element => element.parentElement.open))) await page.keyboard.press('Enter');
  }
  const rawLiteral = await page.locator('.race-record pre').allTextContents();
  assert.deepEqual(rawLiteral, [longUnknown, ...cases.literal_records.slice().reverse()]);
  assert.equal(await page.locator('#fixture-root img, #fixture-root svg, #fixture-root script').count(), 0);
  assert.equal(await page.evaluate(() => window.__race_injected), undefined);
  assert.equal(browserRequests.filter(request => request.method === 'POST').length, 0);
  const literalLayout = await noOverflow();
  groups.push({ id: 'literal_markup_unicode_long_records_390px', status: 'PASS', rawCodeUnits: rawLiteral.map(line => line.length), layout: literalLayout });

  const mandatory = nativeInputs.physics.firstMandatory.state;
  await render(mandatory.log, { mandatory: true, pendingRaceId: mandatory.pendingRaceId, busy: true });
  assert(await page.getByRole('button', { name: 'Enter race', exact: true }).isDisabled());
  await page.locator('#review-before').focus();
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.id), 'review-after');
  assert.deepEqual(await page.evaluate(() => window.__reviewCalls), []);
  await render(mandatory.log, { mandatory: true, pendingRaceId: mandatory.pendingRaceId, busy: false });
  await tabTo('.race-pending button');
  await page.keyboard.press('Enter');
  assert.deepEqual(await page.evaluate(() => window.__reviewCalls), ['race']);
  assert.equal(browserRequests.filter(request => request.method === 'POST').length, 0);
  groups.push({ id: 'native_mandatory_fixture_busy_keyboard_callback', status: 'PASS', nativePendingRace: mandatory.pendingRaceId, callbacks: 1, browserPosts: 0 });

  // One independent real-App receiving flow; broad new-run/stub coverage remains the author's separate run.
  await page.setViewportSize({ width: 1180, height: 850 });
  await page.goto(origin + '/');
  await page.getByRole('button', { name: 'Start run', exact: true }).waitFor();
  await page.waitForFunction(() => { const button = [...document.querySelectorAll('button')].find(button => button.textContent.trim() === 'Start run'); return button && !button.disabled; });
  const setup = page.locator('.card').filter({ has: page.getByRole('heading', { name: 'New career', exact: true }) });
  const field = name => setup.locator('.field').filter({ has: page.locator('label').filter({ hasText: new RegExp('^' + name + '$') }) });
  await field('Seed').locator('input').fill('-317');
  await field('Dialogue').locator('select').selectOption('off');
  await field('Race model').locator('select').selectOption('physics');
  const specialWeek = setup.locator('button.trainee-card').filter({ has: page.locator('.trainee-en', { hasText: /^Special Week$/ }) });
  if (await specialWeek.count()) await specialWeek.first().click();
  const startResponse = page.waitForResponse(response => response.url() === origin + '/v1/run/start' && response.request().method() === 'POST');
  await page.getByRole('button', { name: 'Start run', exact: true }).click();
  const startedSnapshot = await (await startResponse).json();
  assert.equal(startedSnapshot.meta.seed, -317);
  assert.equal(startedSnapshot.state.phase, 'MANDATORY_RACE');
  await page.locator('.race-pending button').waitFor();
  const postsBefore = browserRequests.filter(request => request.endpoint === '/v1/run/action').length;
  actionDelay = new Promise(resolve => { releaseAction = resolve; });
  const firstResponse = page.waitForResponse(response => response.url() === origin + '/v1/run/action' && response.request().method() === 'POST');
  await page.locator('.race-pending button').click();
  await page.waitForFunction(() => document.querySelector('.race-pending button')?.disabled === true);
  await page.keyboard.press('Enter');
  assert.equal(browserRequests.filter(request => request.endpoint === '/v1/run/action').length, postsBefore + 1);
  releaseAction(); releaseAction = null;
  const firstStep = await (await firstResponse).json();
  const firstRecord = firstStep.state.state.log.filter(line => line.startsWith('Race ')).at(-1);
  await page.waitForFunction(() => document.querySelector('.race-latest .race-result')?.getAttribute('data-race-kind') === 'physics');
  assert.deepEqual(await latestFacts(), facts(firstRecord));
  const secondResponse = page.waitForResponse(response => response.url() === origin + '/v1/run/action' && response.request().method() === 'POST');
  await page.locator('.choice-list button.race').click();
  const secondStep = await (await secondResponse).json();
  const records = secondStep.state.state.log.filter(line => line.startsWith('Race '));
  assert.equal(records.length, 2);
  await page.waitForFunction(() => document.querySelector('.race-panel')?.textContent.includes('2 retained race records'));
  const restResponse = page.waitForResponse(response => response.url() === origin + '/v1/run/action' && response.request().method() === 'POST');
  await page.locator('.choice-list button').filter({ hasText: /\bRest$/ }).click();
  const restStep = await (await restResponse).json();
  await page.waitForFunction(() => [...document.querySelectorAll('.choice-list button')].every(button => !button.disabled));
  assert.deepEqual(restStep.state.state.log.filter(line => line.startsWith('Race ')), records);
  assert.deepEqual(await latestFacts(), facts(records.at(-1)));
  const stateBeforeReview = await api('/v1/run/state');
  const stateText = await api('/v1/run/text');
  assert(!stateText.text.includes('Race '), 'ordinary current text omits retained records');
  const actionCountBeforeReview = browserRequests.filter(request => request.endpoint === '/v1/run/action').length;
  await page.locator('.race-history > summary').focus();
  await page.keyboard.press('Enter');
  for (const summary of await page.locator('.race-panel .race-record > summary').all()) {
    await summary.focus();
    await page.keyboard.press('Enter');
  }
  assert.deepEqual(await page.locator('.race-panel .race-record pre').allTextContents(), records.slice().reverse());
  assert.deepEqual(await api('/v1/run/state'), stateBeforeReview);
  assert.equal(browserRequests.filter(request => request.endpoint === '/v1/run/action').length, actionCountBeforeReview);
  await page.setViewportSize({ width: 390, height: 844 });
  const appLayout = await noOverflow();
  const capture = path.join(output, 'independent-phone.png');
  await page.screenshot({ path: capture, fullPage: true });
  const captureBytes = await readFile(capture);
  groups.push({ id: 'real_app_native_mandatory_two_races_rest_readonly_phone', status: 'PASS', start: startedSnapshot.meta, first: firstRecord, recordsAfterRest: records, visibleFacts: await latestFacts(), currentText: stateText.text, actionRequests: actionCountBeforeReview, stateUnchangedByReview: true, layout: appLayout, capture: { path: 'independent-phone.png', bytes: captureBytes.length, sha256: createHash('sha256').update(captureBytes).digest('hex') } });
  assert.deepEqual(pageErrors, []);
} catch (error) {
  groups.push({ id: 'receiver_failure', status: 'FAIL', error: String(error), stack: error?.stack });
  process.exitCode = 1;
} finally {
  if (releaseAction) releaseAction();
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
  child.kill('SIGTERM');
  const receipt = { status: groups.every(group => group.status === 'PASS') ? 'PASS' : 'FAIL', started, finished: new Date().toISOString(), sourceBase: '4dc00f155d29fb37887524455f0627399191c915', sourceHead: 'ab287fed5e5f30b2b999c31c054b234ca1211461', nativeApiSha256: createHash('sha256').update(await readFile(binary)).digest('hex'), nativeInputsSha256: createHash('sha256').update(nativeBytes).digest('hex'), casesSha256: createHash('sha256').update(fixtureBytes).digest('hex'), groups, pageErrors, externalRequests, browserRequests, apiTranscript, nativeStdout, nativeStderr };
  await writeFile(path.join(output, 'browser-review.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ status: receipt.status, groups: groups.map(group => ({ id: group.id, status: group.status, error: group.error })), pageErrors, externalRequests: externalRequests.length, output }));
}
