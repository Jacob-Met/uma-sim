// SPDX-License-Identifier: GPL-3.0-only
// Candidate bindings for the separately frozen independent receiver cases.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, mkdtemp, symlink } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';

const [sourceRoot, outputPath] = process.argv.slice(2);
assert(sourceRoot && outputPath, 'usage: node review-component.mjs FROZEN_SOURCE OUTPUT_JSON');
const owned = '/dev/shm/hamon-afe225d6c6be-engine-uma-review';
const dependencyRequire = createRequire('/workspace/scratch/acd057031fb2/agents/coordination/uma-current/packages/uma-sim-ui/package.json');
const React = dependencyRequire('react');
const { renderToStaticMarkup } = dependencyRequire('react-dom/server');
const ts = dependencyRequire('typescript');
const temporary = await mkdtemp('/dev/hamon-afe225d6c6be-uma-component-receiver-');
await mkdir(path.join(temporary, 'node_modules'));
await symlink(path.dirname(dependencyRequire.resolve('react/package.json')), path.join(temporary, 'node_modules/react'));
const sourcePins = [];
for (const name of ['RacePanel.tsx', 'raceResults.ts']) {
  const source = await readFile(path.join(sourceRoot, 'packages/uma-sim-ui/src/components', name), 'utf8');
  sourcePins.push({ path: name, sha256: createHash('sha256').update(source).digest('hex') });
  const { outputText } = ts.transpileModule(source, { fileName: name, compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX } });
  await writeFile(path.join(temporary, name.replace(/\.tsx?$/, '.js')), outputText, { flag: 'wx' });
}
// Styles are loaded by the actual browser receiver; server rendering does not evaluate CSS.
await writeFile(path.join(temporary, 'race-results.css'), '', { flag: 'wx' });
const require = createRequire(import.meta.url);
const { RacePanel } = require(path.join(temporary, 'RacePanel.js'));
const { parseRaceResults, parseRaceResult } = require(path.join(temporary, 'raceResults.js'));
const fixtureBytes = await readFile(path.join(owned, 'synthetic-cases.json'));
assert.equal(createHash('sha256').update(fixtureBytes).digest('hex'), 'a23a69ef0379871f278a074482c49ed516235396cc7acc671858cb648c087b29');
const cases = JSON.parse(fixtureBytes);
const nativeBytes = await readFile(path.join(owned, 'native-r1/native-inputs.json'));
assert.equal(createHash('sha256').update(nativeBytes).digest('hex'), '3e818210db693d76225d7157e36f37fbc1294d7a4f820d78db84d63db3cd91d6');
const native = JSON.parse(nativeBytes);
const results = [];
function check(id, callback) {
  try { const observations = callback(); results.push({ id, status: 'PASS', observations }); }
  catch (error) { results.push({ id, status: 'FAIL', error: String(error), stack: error?.stack }); }
}
function compareFacts(record, facts) {
  assert.equal(record.kind, 'physics');
  assert.equal(record.summary, facts.raw ?? cases.reference);
  assert.equal(record.raceId, facts.raceId);
  assert.equal(record.place, facts.place);
  assert.equal(record.placeLabel, facts.ordinal);
  assert.equal(record.fieldSize, facts.field);
  assert.equal(record.fanGain, facts.fans);
  assert.equal(Number(record.finishTime), facts.finishSeconds);
  assert.equal(record.courseId, facts.course);
  assert.equal(Number(record.seed), facts.seed);
  assert.equal(Number(record.marginToWinner), facts.marginWinSeconds);
  assert.equal(Number(record.marginAhead), facts.marginAheadSeconds);
  assert.equal(record.finishTime, / t=(\S+)s course=/.exec(record.summary)[1], 'recorded finish precision');
}
const markup = (lines, extra = {}) => renderToStaticMarkup(React.createElement(RacePanel, { lines, mandatory: false, busy: false, onRace: () => { throw Error('render must not act'); }, ...extra }));
const token = key => key.startsWith('unrelated:') ? cases.unrelated[Number(key.split(':')[1])] : cases[key];

check('actual_native_physics_facts_after_ordinary_action', () => {
  const stateLog = Object.freeze([...native.physics.afterOrdinary.snapshot.state.log]);
  const parsed = parseRaceResults(stateLog);
  assert.equal(parsed.length, native.physics.records.length);
  parsed.forEach((record, index) => compareFacts(record, native.physics.records[index]));
  const html = markup(stateLog);
  assert.match(html, /Latest retained race/);
  assert.match(html, /2 retained race records/);
  assert.match(html, /9th/);
  assert.match(html, /74\.133 s/);
  assert.match(html, /\+123/);
  assert.doesNotMatch(html, /1 place/);
  return { records: parsed, currentTextHasRaceRecord: native.physics.afterOrdinary.text.includes('Race ') };
});

check('actual_native_stub_records_have_no_inferred_fields', () => {
  const parsed = parseRaceResults(native.stub.afterOrdinary.snapshot.state.log);
  assert.equal(parsed.length, native.stub.records.length);
  parsed.forEach((record, index) => {
    assert.equal(record.kind, 'fan-only');
    assert.equal(record.summary, native.stub.records[index].raw);
    assert.equal(record.raceId, native.stub.records[index].raceId);
    assert.equal(record.fanGain, native.stub.records[index].fans);
    assert.deepEqual(Object.keys(record).sort(), ['fanGain', 'kind', 'logIndex', 'raceId', 'summary']);
  });
  const html = markup(native.stub.afterOrdinary.snapshot.state.log);
  assert.match(html, /were not recorded/);
  assert.doesNotMatch(html, /<dt>Place<\/dt>|<dt>Finish time<\/dt>|<dt>Field size<\/dt>|1 place/);
  return parsed;
});

check('distinct_synthetic_physics_values_and_decimal_precision', () => {
  compareFacts(parseRaceResult([cases.reference]), { ...cases.reference_facts, raw: cases.reference });
  compareFacts(parseRaceResult([cases.alternate]), { ...cases.alternate_facts, raw: cases.alternate });
  return { reference: parseRaceResult([cases.reference]), alternate: parseRaceResult([cases.alternate]) };
});
check('native_ordinal_grammar_eleven_twelve_thirteen', () => cases.valid_ordinal_controls.map(line => {
  const record = parseRaceResult([line]);
  assert.equal(record.kind, 'physics');
  assert([11, 12, 13].includes(record.place));
  assert.equal(record.placeLabel, `${record.place}th`);
  return record;
}));
for (const test of cases.invalid_physics) check(`malformed_${test.id}_stays_literal_unknown`, () => {
  const changed = cases.reference.replace(test.replace, test.with);
  assert.notEqual(changed, cases.reference);
  const record = parseRaceResult([cases.alternate, changed]);
  assert.deepEqual(record, { kind: 'unknown', logIndex: 1, summary: changed });
  assert.equal(parseRaceResults([changed]).length, 1);
  const html = markup([changed]);
  assert.match(html, /Unrecognized race record/);
  assert.doesNotMatch(html, /<dt>Place<\/dt>|<dt>Finish time<\/dt>|<dt>Field size<\/dt>|<dt>Fan gain<\/dt>/);
  return { raw: changed, kind: record.kind };
});
for (const test of cases.log_scenarios.filter(test => test.tokens)) check(`log_${test.id}`, () => {
  const lines = test.tokens.map(token);
  const before = [...lines];
  const records = parseRaceResults(lines);
  assert.deepEqual(lines, before, 'parser must leave supplied log untouched');
  assert.equal(records.length, test.expectedOccurrences);
  const indices = lines.flatMap((line, index) => /^Race(?:\s|$)/u.test(line) ? [index] : []);
  assert.deepEqual(records.map(record => record.logIndex), indices);
  assert.deepEqual(records.map(record => record.summary), indices.map(index => lines[index]));
  assert.equal(parseRaceResult(lines)?.summary ?? null, test.latest ? token(test.latest) : null);
  if (test.latest === 'unknown') assert.equal(records.at(-1).kind, 'unknown');
  if (test.latest === 'stub') assert.equal(records.at(-1).kind, 'fan-only');
  return { records };
});
check('literal_markup_and_unicode_are_escaped_in_real_react', () => cases.literal_records.map(line => {
  const html = markup([line]);
  assert.doesNotMatch(html, /<img\b|<svg\b|<script\b/);
  if (line.includes('<')) assert.match(html, /&lt;/);
  assert.equal(parseRaceResult([line]).summary, line);
  return { raw: line, html };
}));
check('mandatory_and_busy_retained_control', () => {
  const state = native.physics.firstMandatory.state;
  assert.equal(state.phase, 'MANDATORY_RACE');
  const enabled = markup(state.log, { mandatory: true, pendingRaceId: state.pendingRaceId });
  const disabled = markup(state.log, { mandatory: true, pendingRaceId: state.pendingRaceId, busy: true });
  assert.match(enabled, />Enter race<\/button>/);
  assert.doesNotMatch(enabled, /<button[^>]*disabled/);
  assert.match(disabled, /<button[^>]*disabled[^>]*>Enter race<\/button>/);
  return { mandatoryRaceId: state.pendingRaceId, enabled, disabled };
});

const receipt = { status: results.every(result => result.status === 'PASS') ? 'PASS' : 'FAIL', executedAt: new Date().toISOString(), sourceBase: '4dc00f155d29fb37887524455f0627399191c915', sourceHead: 'ab287fed5e5f30b2b999c31c054b234ca1211461', sourcePins, frozenCasesSha256: createHash('sha256').update(fixtureBytes).digest('hex'), nativeInputsSha256: createHash('sha256').update(nativeBytes).digest('hex'), dependencyVersions: { node: process.version, react: dependencyRequire('react/package.json').version, typescript: ts.version }, groups: results };
await writeFile(outputPath, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: receipt.status, groups: results.length, failed: results.filter(result => result.status !== 'PASS'), outputPath }));
if (receipt.status !== 'PASS') process.exitCode = 1;
