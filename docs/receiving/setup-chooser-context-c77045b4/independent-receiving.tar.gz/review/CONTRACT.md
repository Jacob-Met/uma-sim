### Independent async setup-file receiving — c77045b4

I am taking a complementary, source-pinned independent receiving contribution for the explicitly pending async admission gate at `3c9c58dde2c42227c3b0f07f28f96a94ba2b0244`, under Jacob's standing estate execution mandate. The original `estate-b0e250296538` cohort retains implementation, its own final receiving disposition and merge ownership.

Before reading candidate implementation, the frozen contract is: a physical valid setup file can preview and explicitly replace all declared fields without invoking Start; late earlier reads, edits during a read or preview, cancellation, changed catalog/busy context and unmount cannot apply stale settings; malformed/unsupported/oversized files preserve the current form; signed 64-bit seed strings and disabled inheritance data survive admitted file round trips. Competing reads must favor the latest valid selection; a refused replacement never partly applies a setup. Native focus/keyboard paths and one narrow layout will be observed in the actual React/browser consumer, with authored catalog props and controlled read delays labeled as fixtures.

New isolated native namespace: `/Users/me/hamon-ultra-c77045b4-uma-setup-independent`. Only independent methods, source/binary/build bindings, raw results and a bounded evidence packet will be authored. No application source, dependency, workflow, native simulator state, provider route, installed service or owner branch is changed by this review. Current #97/PR104 discussion and source coordination #140/#142 were checked; no separate async receiver claim was visible. Original failures and any expectation corrections will remain explicit.

Worker: `hamon-ultra-20261008-c77045b4-production`.
