import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const modules='/Users/me/workspace/estate/contributions-b0e250296538-20261008/uma-setup-author/candidate/packages/uma-sim-ui/node_modules';
const {build}=await import(path.join(modules,'vite/dist/node/index.js'));
const source=path.join(root,'candidate/packages/uma-sim-ui');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const lock=await readFile(path.join(source,'package-lock.json'));
if(hash(lock)!=='b306b84fc9fb3285a442d8360a419eba3276d3d4effda266205832331ac1dc99')throw Error('Source lock differs');
const peerLock=await readFile(path.resolve(modules,'../package-lock.json'));
if(!lock.equals(peerLock))throw Error('Installed peer lock differs');
const sourceManifest=JSON.parse(await readFile(path.join(root,'candidate/docs/receiving/run-setup-b0e250296538/SOURCE_MANIFEST.json'),'utf8'));
const inputMap=sourceManifest.native_current_input_manifest;
const inputs={};
for(const [p,pin] of Object.entries(inputMap)){const bytes=await readFile(path.join(root,'candidate',p));if(hash(bytes)!==pin.sha256)throw Error('Input differs: '+p);inputs[p]={bytes:bytes.length,sha256:hash(bytes)};}
const pkgNames=['react','react-dom','vite','typescript','playwright'];
const toolchain=Object.fromEntries(await Promise.all(pkgNames.map(async name=>{const file=path.join(modules,name,'package.json'),bytes=await readFile(file);return [name,{version:JSON.parse(bytes).version,packageSha256:hash(bytes),path:file}]})));
await mkdir(path.join(root,'evidence'),{recursive:true});
await writeFile(path.join(root,'evidence/source-before-build.json'),JSON.stringify({head:'3c9c58dde2c42227c3b0f07f28f96a94ba2b0244',tree:'3f9587f7814ec781835ff39351af43328f637dd3',checkedAt:new Date().toISOString(),runtime:process.version,toolchain,inputs},null,2)+'\n');
await build({configFile:false,root:path.join(root,'review/view'),cacheDir:path.join(root,'review/.vite-cache'),base:'./',resolve:{alias:{react:path.join(modules,'react'),'react-dom':path.join(modules,'react-dom')}},esbuild:{jsx:'automatic'},build:{outDir:path.join(root,'review-dist'),emptyOutDir:true},logLevel:'info'});
for(const [p,pin] of Object.entries(inputMap)){const bytes=await readFile(path.join(root,'candidate',p));if(hash(bytes)!==pin.sha256)throw Error('Input changed in build: '+p);}
console.log(JSON.stringify({passed:true,sourceFiles:Object.keys(inputs).length,toolchain,sourceUnchanged:true}));
