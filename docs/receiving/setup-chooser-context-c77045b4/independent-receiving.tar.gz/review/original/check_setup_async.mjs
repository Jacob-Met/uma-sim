import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { once } from 'node:events';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const output=path.resolve(process.argv[2]||path.join(root,'evidence/browser-v1'));
const modules='/Users/me/workspace/estate/contributions-b0e250296538-20261008/uma-setup-author/candidate/packages/uma-sim-ui/node_modules';
const {chromium}=await import(path.join(modules,'playwright/index.mjs'));
const fixtures=JSON.parse(await fs.readFile(path.join(root,'review/fixtures.json'),'utf8'));
const sha256=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
await fs.mkdir(output,{recursive:false});
const inputs=path.join(output,'inputs');await fs.mkdir(inputs);
const cases={
  'setup-A.json':Buffer.from(JSON.stringify(fixtures.setupA,null,2)+'\n'),
  'setup-B.json':Buffer.from(JSON.stringify(fixtures.setupB,null,2)+'\n'),
  'slow-A.json':Buffer.from(JSON.stringify(fixtures.setupA,null,2)+'\n'),
  'bad-utf8.json':Buffer.from([0xff,0xfe,0xfd]),
  'bad-json.json':Buffer.from('{"schema":'),
  'wrong-version.json':Buffer.from(JSON.stringify({...fixtures.setupA,version:2})),
  'extra-field.json':Buffer.from(JSON.stringify({...fixtures.setupA,unexpected:true})),
  'over-limit.json':Buffer.alloc(65537,32),
  'bad-seed.json':Buffer.from(JSON.stringify({...fixtures.setupA,setup:{...fixtures.setupA.setup,seed:'9223372036854775808'}})),
  'unavailable-factor.json':Buffer.from(JSON.stringify({...fixtures.setupA,setup:{...fixtures.setupA.setup,legacyTree:{...fixtures.setupA.setup.legacyTree,parentA:{...fixtures.setupA.setup.legacyTree.parentA,blue:{factorId:'not-in-receiver-catalog',stars:3}}}}})),
};
for(const[name,bytes]of Object.entries(cases))await fs.writeFile(path.join(inputs,name),bytes);
const buildRoot=path.join(root,'review-dist'),served=[],requested=[],external=[],pageErrors=[],groups=[];
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://127.0.0.1');
    const name=url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname);
    const file=path.resolve(buildRoot,'.'+name);
    if(!file.startsWith(buildRoot+path.sep))throw Error('Outside build');
    const bytes=await fs.readFile(file);
    res.setHeader('content-type',name.endsWith('.html')?'text/html':name.endsWith('.js')?'application/javascript':name.endsWith('.css')?'text/css':'application/octet-stream');
    res.setHeader('cache-control','no-store');
    served.push({url:req.url,path:path.relative(buildRoot,file),sha256:sha256(bytes),bytes:bytes.length});
    res.end(bytes);
  }catch{res.writeHead(404);res.end('Not found');}
});
server.listen(0,'127.0.0.1');await once(server,'listening');
const origin='http://127.0.0.1:'+server.address().port;
const profile=path.join(root,'profiles','browser-v1-'+Date.now());await fs.mkdir(path.dirname(profile),{recursive:true});
let context;
const report={contract:'review/CONTRACT.md',sourceHead:'3c9c58dde2c42227c3b0f07f28f96a94ba2b0244',sourceTree:'3f9587f7814ec781835ff39351af43328f637dd3',runtime:process.version,startedAt:new Date().toISOString(),method:'Real unmodified React RunSetup and RunSetupFiles compiled with locked native Vite; authored catalog props and controlled File.arrayBuffer timing; filechooser/physical browser downloads; no simulator API',groups,served,requested,external,pageErrors};
async function settle(page){await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));}
async function seed(page,value){await page.locator('#setup-seed').fill(value);await settle(page);}
async function chooser(page){const next=page.waitForEvent('filechooser');await page.getByRole('button',{name:'Open setup',exact:true}).click();return next;}
async function open(page,name){const file=await chooser(page);await file.setFiles(path.join(inputs,name));await settle(page);}
async function reviewVisible(page){return page.getByRole('heading',{name:'Review setup',exact:true}).isVisible();}
async function noStart(page){assert.deepEqual(JSON.parse(await page.getByTestId('starts').textContent()),[]);}
async function download(page,label){
  const pending=page.waitForEvent('download');await page.getByRole('button',{name:'Download setup',exact:true}).click();const file=await pending;
  assert.equal(file.suggestedFilename(),'uma-sim-setup-v1.json');
  const destination=path.join(output,label+'.json');await file.saveAs(destination);
  const bytes=await fs.readFile(destination);return {value:JSON.parse(bytes),path:destination,sha256:sha256(bytes),bytes:bytes.length};
}
async function hold(page){await open(page,'slow-A.json');await page.waitForFunction(()=>Boolean(window.__pendingReads['slow-A.json']));assert.equal(await page.getByText('Reading setup file…',{exact:true}).isVisible(),true);}
async function release(page){await page.evaluate(()=>window.__pendingReads['slow-A.json'].release());await settle(page);}
async function fresh(){
  const page=await context.newPage();
  page.on('pageerror',error=>pageErrors.push({message:error.message}));
  await page.addInitScript(()=>{
    window.__pendingReads={};
    const original=File.prototype.arrayBuffer;
    File.prototype.arrayBuffer=function(){
      const bytes=original.call(this);
      if(!this.name.startsWith('slow-'))return bytes;
      const name=this.name;
      return new Promise((resolve,reject)=>{
        window.__pendingReads[name]={release:async()=>{delete window.__pendingReads[name];try{resolve(await bytes);}catch(e){reject(e);}}};
      });
    };
  });
  await page.goto(origin,{waitUntil:'networkidle'});
  await page.getByRole('heading',{name:'New career',exact:true}).waitFor();
  assert.equal(await page.locator('#setup-seed').inputValue(),'42');
  return page;
}
async function group(name,fn){
  const page=await fresh();const entry={name,startedAt:new Date().toISOString(),passed:false};groups.push(entry);
  try{entry.observations=await fn(page);entry.passed=true;console.log('PASS '+name);}
  catch(error){entry.error={name:error.name,message:error.message,stack:error.stack};entry.seed=await page.locator('#setup-seed').inputValue().catch(()=>null);entry.preview=await reviewVisible(page).catch(()=>null);await fs.writeFile(path.join(output,name+'-failure.html'),await page.content());await page.screenshot({path:path.join(output,name+'-failure.png'),fullPage:true});console.log('FAIL '+name+': '+error.message);}
  finally{entry.finishedAt=new Date().toISOString();await page.close();await fs.writeFile(path.join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');}
}
try{
  context=await chromium.launchPersistentContext(profile,{executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,acceptDownloads:true,viewport:{width:1280,height:900}});
  report.browser=context.browser()?.version()??'persistent-context';
  await context.route('**/*',route=>{const u=route.request().url();requested.push({url:u,method:route.request().method()});if(u.startsWith(origin+'/'))return route.continue();external.push(u);return route.abort();});
  await group('01-valid-explicit-replace-roundtrip',async page=>{
    await open(page,'setup-A.json');assert.equal(await reviewVisible(page),true);assert.equal(await page.locator('#setup-seed').inputValue(),'42');await noStart(page);
    await page.getByRole('button',{name:'Cancel',exact:true}).click();assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'42');
    await open(page,'setup-A.json');await page.getByRole('button',{name:'Replace setup',exact:true}).click();assert.equal(await page.locator('#setup-seed').inputValue(),fixtures.setupA.setup.seed);await noStart(page);
    const saved=await download(page,'valid-roundtrip');assert.deepEqual(saved.value,fixtures.setupA);return saved;
  });
  await group('02-later-file-wins-held-read',async page=>{
    await hold(page);await open(page,'setup-B.json');assert.equal(await reviewVisible(page),true);await release(page);
    assert.equal(await page.locator('.setup-file-review code').first().textContent(),fixtures.setupB.setup.seed);
    await page.getByRole('button',{name:'Replace setup',exact:true}).click();const saved=await download(page,'newer-file-roundtrip');assert.deepEqual(saved.value,fixtures.setupB);await noStart(page);return saved;
  });
  await group('03-edit-during-read',async page=>{
    await hold(page);await seed(page,'77');await release(page);assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'77');await noStart(page);return {preservedSeed:'77'};
  });
  await group('04-catalog-change-during-read',async page=>{
    await hold(page);await page.getByTestId('catalog-refresh').click();await release(page);assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'42');await noStart(page);return {sameCatalogValuesNewIdentity:true};
  });
  await group('05-busy-cycle-during-read',async page=>{
    await hold(page);await page.getByTestId('busy').click();await settle(page);await page.getByTestId('busy').click();await release(page);assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'42');await noStart(page);return {busyReturnedFalse:true,oldReadRetired:true};
  });
  await group('06-cancel-held-read',async page=>{
    await hold(page);await page.getByRole('button',{name:'Cancel opening',exact:true}).click();await release(page);assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'42');await noStart(page);return {cancelPreservedForm:true};
  });
  await group('07-edit-and-catalog-retire-previews',async page=>{
    await open(page,'setup-A.json');await seed(page,'88');assert.equal(await reviewVisible(page),false);await open(page,'setup-A.json');await page.getByTestId('catalog-remove').click();await settle(page);assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'88');await noStart(page);return {preservedSeed:'88',previewRetiredTwice:true};
  });
  await group('08-unmount-held-read',async page=>{
    await hold(page);await page.getByTestId('mount').click();await settle(page);await page.getByTestId('mount').click();await settle(page);await release(page);assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'42');await noStart(page);return {remountedWithInitialState:true};
  });
  await group('09-invalid-physical-file-refusals',async page=>{
    await seed(page,'314');const refused=[];
    for(const name of Object.keys(cases).filter(name=>!['setup-A.json','setup-B.json','slow-A.json'].includes(name))){
      await open(page,name);await page.getByRole('alert').waitFor();assert.equal(await reviewVisible(page),false);assert.equal(await page.locator('#setup-seed').inputValue(),'314');await noStart(page);refused.push({name,message:await page.getByRole('alert').textContent()});
    }return {refused};
  });
  await group('10-catalog-change-while-chooser-open',async page=>{
    const file=await chooser(page);await page.getByTestId('catalog-refresh').click();await settle(page);await file.setFiles(path.join(inputs,'setup-A.json'));await settle(page);
    assert.equal(await reviewVisible(page),false,'An old chooser selection must be retired after the available-catalog context changed');
    assert.equal(await page.locator('#setup-seed').inputValue(),'42');await noStart(page);return {oldChooserRetired:true};
  });
  await group('11-edit-while-chooser-open',async page=>{
    const file=await chooser(page);await seed(page,'2718');await file.setFiles(path.join(inputs,'setup-A.json'));await settle(page);
    assert.equal(await reviewVisible(page),false,'An old chooser selection must be retired after the form changed');
    assert.equal(await page.locator('#setup-seed').inputValue(),'2718');await noStart(page);return {oldChooserRetired:true,preservedSeed:'2718'};
  });
  await group('12-keyboard-phone-and-explicit-start',async page=>{
    await page.setViewportSize({width:390,height:844});const pending=page.waitForEvent('filechooser');const button=page.getByRole('button',{name:'Open setup',exact:true});await button.focus();await page.keyboard.press('Enter');const file=await pending;await file.setFiles(path.join(inputs,'setup-B.json'));await page.getByRole('heading',{name:'Review setup',exact:true}).waitFor();
    const box=await page.locator('.setup-file-review').boundingBox();assert(box&&box.x>=0&&box.x+box.width<=390.5,'Preview outside viewport');
    await page.locator('.setup-file-review').screenshot({path:path.join(output,'phone-review.png')});
    const replace=page.getByRole('button',{name:'Replace setup',exact:true});await replace.focus();await page.keyboard.press('Enter');await noStart(page);
    const saved=await download(page,'keyboard-roundtrip');assert.deepEqual(saved.value,fixtures.setupB);
    await page.getByRole('button',{name:'Start run',exact:true}).click();const starts=JSON.parse(await page.getByTestId('starts').textContent());assert.equal(starts.length,1);assert.equal(starts[0].seed,fixtures.setupB.setup.seed);assert.equal(starts[0].policy,fixtures.setupB.setup.policy);assert.equal(starts[0].legacyTree,undefined);await page.screenshot({path:path.join(output,'phone-applied.png'),fullPage:true});
    return {previewBox:box,saved,starts,scope:'Start callback only; no API or simulator execution'};
  });
  assert.deepEqual(external,[],'Unexpected external requests');
  assert.deepEqual(pageErrors,[],'Page exceptions');
}catch(error){report.fatal={name:error.name,message:error.message,stack:error.stack};}
finally{
  if(context)await context.close();
  server.close();await once(server,'close');
  await fs.rm(profile,{recursive:true,force:true});
  report.finishedAt=new Date().toISOString();report.passed=!report.fatal&&groups.length===12&&groups.every(x=>x.passed)&&external.length===0&&pageErrors.length===0;report.passedGroups=groups.filter(x=>x.passed).length;report.failedGroups=groups.filter(x=>!x.passed).length;
  const source=JSON.parse(await fs.readFile(path.join(root,'evidence/source-before-build.json'),'utf8'));
  for(const [p,pin]of Object.entries(source.inputs)){assert.equal(sha256(await fs.readFile(path.join(root,'candidate',p))),pin.sha256,'Source changed '+p);}
  report.sourceInputsUnchanged=Object.keys(source.inputs).length;
  report.ownedBrowserAndServerClosed=true;report.ownedProfileRemoved=true;
  await fs.writeFile(path.join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({passed:report.passed,passedGroups:report.passedGroups,failedGroups:report.failedGroups,fatal:report.fatal,external:external.length,pageErrors:pageErrors.length,sourceInputsUnchanged:report.sourceInputsUnchanged,output}));
  process.exitCode=report.passed?0:1;
}
