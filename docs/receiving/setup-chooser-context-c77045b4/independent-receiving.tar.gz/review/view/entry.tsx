import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { RunSetup } from "../../candidate/packages/uma-sim-ui/src/components/RunSetup";
import "../../candidate/packages/uma-sim-ui/src/styles/app.css";
import fixtures from "../fixtures.json";

function Receiver() {
  const [busy, setBusy] = useState(false);
  const [catalogs, setCatalogs] = useState(fixtures.catalogs);
  const [present, setPresent] = useState(true);
  const [starts, setStarts] = useState<unknown[]>([]);
  return <main>
    <section aria-label="Independent receiver context" style={{padding:"12px", border:"1px solid #aaa"}}>
      <p>Independent receiver fixture — actual unmodified RunSetup; authored catalogs; no native API.</p>
      <button data-testid="catalog-refresh" onClick={() => setCatalogs(structuredClone(fixtures.catalogs))}>Fixture: refresh equal catalog</button>
      <button data-testid="catalog-remove" onClick={() => setCatalogs({...catalogs, supports:catalogs.supports.slice(0,2)})}>Fixture: remove saved support choices</button>
      <button data-testid="busy" onClick={() => setBusy(value => !value)}>Fixture busy: {String(busy)}</button>
      <button data-testid="mount" onClick={() => setPresent(value => !value)}>Fixture component: {present?"mounted":"unmounted"}</button>
      <output data-testid="starts">{JSON.stringify(starts)}</output>
    </section>
    {present && <RunSetup {...catalogs} busy={busy} onStart={(request) => setStarts(value => [...value,request])}/>}
  </main>;
}
createRoot(document.getElementById("root")!).render(<Receiver/>);
